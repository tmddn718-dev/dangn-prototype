/* @ds-bundle: {"format":4,"namespace":"SEEDDesignSystem_bc7187","components":[{"name":"ActionButton","sourcePath":"components/actions/ActionButton.jsx"},{"name":"ContextualFloatingButton","sourcePath":"components/actions/ContextualFloatingButton.jsx"},{"name":"FloatingActionButton","sourcePath":"components/actions/FloatingActionButton.jsx"},{"name":"ReactionButton","sourcePath":"components/actions/ReactionButton.jsx"},{"name":"ToggleButton","sourcePath":"components/actions/ToggleButton.jsx"},{"name":"Icon","sourcePath":"components/core/Icon.jsx"},{"name":"PrefixIcon","sourcePath":"components/core/Icon.jsx"},{"name":"SuffixIcon","sourcePath":"components/core/Icon.jsx"},{"name":"Glyph","sourcePath":"components/core/Icon.jsx"},{"name":"Avatar","sourcePath":"components/display/Avatar.jsx"},{"name":"AvatarStack","sourcePath":"components/display/Avatar.jsx"},{"name":"Badge","sourcePath":"components/display/Badge.jsx"},{"name":"Divider","sourcePath":"components/display/Divider.jsx"},{"name":"MannerTempBadge","sourcePath":"components/display/MannerTempBadge.jsx"},{"name":"MannerTemp","sourcePath":"components/display/MannerTempBadge.jsx"},{"name":"NotificationBadge","sourcePath":"components/display/NotificationBadge.jsx"},{"name":"ProgressCircle","sourcePath":"components/display/ProgressCircle.jsx"},{"name":"ResultSection","sourcePath":"components/display/ResultSection.jsx"},{"name":"Skeleton","sourcePath":"components/display/Skeleton.jsx"},{"name":"TagGroup","sourcePath":"components/display/TagGroup.jsx"},{"name":"Text","sourcePath":"components/display/Text.jsx"},{"name":"Callout","sourcePath":"components/feedback/Callout.jsx"},{"name":"HelpBubble","sourcePath":"components/feedback/HelpBubble.jsx"},{"name":"PageBanner","sourcePath":"components/feedback/PageBanner.jsx"},{"name":"Snackbar","sourcePath":"components/feedback/Snackbar.jsx"},{"name":"Checkmark","sourcePath":"components/forms/Checkbox.jsx"},{"name":"Checkbox","sourcePath":"components/forms/Checkbox.jsx"},{"name":"Chip","sourcePath":"components/forms/Chip.jsx"},{"name":"QuantityPicker","sourcePath":"components/forms/QuantityPicker.jsx"},{"name":"Radiomark","sourcePath":"components/forms/RadioGroup.jsx"},{"name":"RadioGroup","sourcePath":"components/forms/RadioGroup.jsx"},{"name":"SegmentedControl","sourcePath":"components/forms/SegmentedControl.jsx"},{"name":"SelectBox","sourcePath":"components/forms/SelectBox.jsx"},{"name":"Switch","sourcePath":"components/forms/Switch.jsx"},{"name":"TextField","sourcePath":"components/forms/TextField.jsx"},{"name":"AppBar","sourcePath":"components/navigation/AppBar.jsx"},{"name":"ChipTabs","sourcePath":"components/navigation/ChipTabs.jsx"},{"name":"ListItem","sourcePath":"components/navigation/ListItem.jsx"},{"name":"List","sourcePath":"components/navigation/ListItem.jsx"},{"name":"ListHeader","sourcePath":"components/navigation/ListItem.jsx"},{"name":"Tabs","sourcePath":"components/navigation/Tabs.jsx"},{"name":"AlertDialog","sourcePath":"components/overlays/AlertDialog.jsx"},{"name":"BottomSheet","sourcePath":"components/overlays/BottomSheet.jsx"},{"name":"MenuSheet","sourcePath":"components/overlays/MenuSheet.jsx"}],"sourceHashes":{"components/actions/ActionButton.jsx":"b2b671fce5a1","components/actions/ContextualFloatingButton.jsx":"ff5eba0bdfdc","components/actions/FloatingActionButton.jsx":"9965784ed20c","components/actions/ReactionButton.jsx":"65d6490c3193","components/actions/ToggleButton.jsx":"891224b8a540","components/core/Icon.jsx":"e49fbf2f3c7f","components/display/Avatar.jsx":"5e64dbf08fbc","components/display/Badge.jsx":"2225de6b212d","components/display/Divider.jsx":"93404ff6e2b8","components/display/MannerTempBadge.jsx":"663bb474115c","components/display/NotificationBadge.jsx":"6399e61a1c48","components/display/ProgressCircle.jsx":"6f503fec385e","components/display/ResultSection.jsx":"e8182ce703b9","components/display/Skeleton.jsx":"556a5e8e63d4","components/display/TagGroup.jsx":"b4f5a3e55719","components/display/Text.jsx":"f19da757efe2","components/feedback/Callout.jsx":"a7bf9cab93e2","components/feedback/HelpBubble.jsx":"0e79001e97d4","components/feedback/PageBanner.jsx":"1bffd05685b0","components/feedback/Snackbar.jsx":"329d15173803","components/forms/Checkbox.jsx":"a46e2a468088","components/forms/Chip.jsx":"d6c4423cdc83","components/forms/QuantityPicker.jsx":"c751a6c99856","components/forms/RadioGroup.jsx":"df91760c6d84","components/forms/SegmentedControl.jsx":"118b7a79f4b6","components/forms/SelectBox.jsx":"23d2c921ea3f","components/forms/Switch.jsx":"eafea918a692","components/forms/TextField.jsx":"80bc82078eae","components/navigation/AppBar.jsx":"d65db47b5487","components/navigation/ChipTabs.jsx":"b2cee7e16931","components/navigation/ListItem.jsx":"47a2e40a9952","components/navigation/Tabs.jsx":"d5c87313354d","components/overlays/AlertDialog.jsx":"3eb03ad787f4","components/overlays/BottomSheet.jsx":"ef01829a8901","components/overlays/MenuSheet.jsx":"93fa83d35205","ui_kits/seed-demo-app/ArticleDetailScreen.jsx":"fc5a8e6fcae7","ui_kits/seed-demo-app/FilterBottomSheet.jsx":"974bef04139f","ui_kits/seed-demo-app/HomeScreen.jsx":"01d039b3b05b","ui_kits/seed-demo-app/data.js":"6a7db7f8ea22"},"inlinedExternals":[],"unexposedExports":[{"name":"glyphs","sourcePath":"components/core/Icon.jsx"},{"name":"mannerTempToLevel","sourcePath":"components/display/MannerTempBadge.jsx"}]} */

(() => {

const __ds_ns = (window.SEEDDesignSystem_bc7187 = window.SEEDDesignSystem_bc7187 || {});

const __ds_scope = {};

(__ds_ns.__errors = __ds_ns.__errors || []);

// components/actions/ContextualFloatingButton.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
const cx = (...a) => a.filter(Boolean).join(" ");
const rc = (b, v, pairs) => {
  const o = [b];
  for (const k in v || {}) if (v[k] != null && v[k] !== false) o.push(b + "--" + k + "_" + v[k]);
  for (const p of pairs || []) if (v[p[0]] != null && v[p[1]] != null) o.push(b + "--" + p[0] + "_" + v[p[0]] + "-" + p[1] + "_" + v[p[1]]);
  return o.join(" ");
};
const da = on => on ? "" : undefined;
function ContextualFloatingButton({
  variant = "solid",
  layout = "withText",
  className,
  style,
  children,
  ...rest
}) {
  return /*#__PURE__*/React.createElement("button", _extends({
    type: "button",
    className: cx(rc("seed-contextual-floating-button", {
      variant,
      layout
    }), className),
    style: {
      "--seed-feedback-scale": 0.95,
      ...style
    }
  }, rest), children);
}
Object.assign(__ds_scope, { ContextualFloatingButton });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/actions/ContextualFloatingButton.jsx", error: String((e && e.message) || e) }); }

// components/actions/FloatingActionButton.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
const cx = (...a) => a.filter(Boolean).join(" ");
const rc = (b, v, pairs) => {
  const o = [b];
  for (const k in v || {}) if (v[k] != null && v[k] !== false) o.push(b + "--" + k + "_" + v[k]);
  for (const p of pairs || []) if (v[p[0]] != null && v[p[1]] != null) o.push(b + "--" + p[0] + "_" + v[p[0]] + "-" + p[1] + "_" + v[p[1]]);
  return o.join(" ");
};
const da = on => on ? "" : undefined;
function FloatingActionButton({
  icon,
  label,
  extended = false,
  className,
  style,
  ...rest
}) {
  return /*#__PURE__*/React.createElement("button", _extends({
    type: "button",
    "aria-label": typeof label === "string" ? label : undefined,
    className: cx(rc("seed-floating-action-button__root", {
      extended: String(extended)
    }), className),
    style: {
      "--seed-feedback-scale": 0.96,
      ...style
    }
  }, rest), /*#__PURE__*/React.createElement("span", {
    className: rc("seed-floating-action-button__icon", {
      extended: String(extended)
    }),
    style: {
      display: "inline-flex"
    }
  }, icon), /*#__PURE__*/React.createElement("span", {
    className: rc("seed-floating-action-button__label", {
      extended: String(extended)
    })
  }, label));
}
Object.assign(__ds_scope, { FloatingActionButton });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/actions/FloatingActionButton.jsx", error: String((e && e.message) || e) }); }

// components/actions/ReactionButton.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
const cx = (...a) => a.filter(Boolean).join(" ");
const rc = (b, v, pairs) => {
  const o = [b];
  for (const k in v || {}) if (v[k] != null && v[k] !== false) o.push(b + "--" + k + "_" + v[k]);
  for (const p of pairs || []) if (v[p[0]] != null && v[p[1]] != null) o.push(b + "--" + p[0] + "_" + v[p[0]] + "-" + p[1] + "_" + v[p[1]]);
  return o.join(" ");
};
const da = on => on ? "" : undefined;
function ReactionButton({
  size = "small",
  pressed,
  defaultPressed = false,
  onPressedChange,
  disabled,
  count,
  className,
  style,
  children,
  ...rest
}) {
  const [inner, setInner] = React.useState(defaultPressed);
  const on = pressed ?? inner;
  const toggle = () => {
    if (pressed == null) setInner(!on);
    onPressedChange && onPressedChange(!on);
  };
  return /*#__PURE__*/React.createElement("button", _extends({
    type: "button",
    "aria-pressed": on,
    className: cx(rc("seed-reaction-button", {
      size
    }), className),
    "data-pressed": da(on),
    disabled: disabled,
    "data-disabled": da(disabled),
    onClick: toggle,
    style: {
      "--seed-feedback-scale": 0.95,
      ...style
    }
  }, rest), children, count != null && /*#__PURE__*/React.createElement("span", {
    className: "seed-count",
    style: {
      fontWeight: 700
    }
  }, count));
}
Object.assign(__ds_scope, { ReactionButton });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/actions/ReactionButton.jsx", error: String((e && e.message) || e) }); }

// components/actions/ToggleButton.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
const cx = (...a) => a.filter(Boolean).join(" ");
const rc = (b, v, pairs) => {
  const o = [b];
  for (const k in v || {}) if (v[k] != null && v[k] !== false) o.push(b + "--" + k + "_" + v[k]);
  for (const p of pairs || []) if (v[p[0]] != null && v[p[1]] != null) o.push(b + "--" + p[0] + "_" + v[p[0]] + "-" + p[1] + "_" + v[p[1]]);
  return o.join(" ");
};
const da = on => on ? "" : undefined;
function ToggleButton({
  variant = "brandSolid",
  size = "small",
  pressed,
  defaultPressed = false,
  onPressedChange,
  disabled,
  className,
  style,
  children,
  ...rest
}) {
  const [inner, setInner] = React.useState(defaultPressed);
  const on = pressed ?? inner;
  const toggle = () => {
    if (pressed == null) setInner(!on);
    onPressedChange && onPressedChange(!on);
  };
  return /*#__PURE__*/React.createElement("button", _extends({
    type: "button",
    "aria-pressed": on,
    className: cx(rc("seed-toggle-button", {
      variant,
      size
    }), className),
    "data-pressed": da(on),
    disabled: disabled,
    "data-disabled": da(disabled),
    onClick: toggle,
    style: {
      "--seed-feedback-scale": 0.95,
      ...style
    }
  }, rest), children);
}
Object.assign(__ds_scope, { ToggleButton });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/actions/ToggleButton.jsx", error: String((e && e.message) || e) }); }

// components/core/Icon.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
const cx = (...a) => a.filter(Boolean).join(" ");
const rc = (b, v, pairs) => {
  const o = [b];
  for (const k in v || {}) if (v[k] != null && v[k] !== false) o.push(b + "--" + k + "_" + v[k]);
  for (const p of pairs || []) if (v[p[0]] != null && v[p[1]] != null) o.push(b + "--" + p[0] + "_" + v[p[0]] + "-" + p[1] + "_" + v[p[1]]);
  return o.join(" ");
};
const da = on => on ? "" : undefined;
const svgCache = {};
function useSvgMarkup(src) {
  const [markup, setMarkup] = React.useState(src ? svgCache[src] || null : null);
  React.useEffect(() => {
    if (!src) return;
    if (svgCache[src]) {
      setMarkup(svgCache[src]);
      return;
    }
    let alive = true;
    fetch(src).then(r => r.text()).then(t => {
      const m = t.replace(/<\?xml[^>]*>/, "").replace(/\s(width|height)="[^"]*"/g, "").replace("<svg", '<svg width="100%" height="100%" style="display:block"');
      svgCache[src] = m;
      if (alive) setMarkup(m);
    }).catch(() => {});
    return () => {
      alive = false;
    };
  }, [src]);
  return markup;
}

/** Renders a SEED icon. Pass "src" (path to an SVG from assets/svg; fetched and inlined so fill=currentColor follows text color) or "svg" (an inline svg node). */
function Icon({
  src,
  svg,
  size,
  color,
  slot = "icon",
  className,
  style
}) {
  const base = slot === "prefix" ? "seed-prefix-icon" : slot === "suffix" ? "seed-suffix-icon" : slot === "none" ? null : "seed-icon";
  const markup = useSvgMarkup(svg ? null : src);
  const st = {
    ...(style || {})
  };
  if (size != null) st["--seed-icon-size"] = typeof size === "number" ? size + "px" : size;
  if (color) st["--seed-icon-color"] = color;
  if (slot === "none" && size != null) {
    st.width = st["--seed-icon-size"];
    st.height = st["--seed-icon-size"];
    st.display = "inline-block";
    st.flexShrink = 0;
  }
  if (!svg && markup) return /*#__PURE__*/React.createElement("span", {
    "aria-hidden": "true",
    className: cx(base, className),
    style: st,
    dangerouslySetInnerHTML: {
      __html: markup
    }
  });
  return /*#__PURE__*/React.createElement("span", {
    "aria-hidden": "true",
    className: cx(base, className),
    style: st
  }, svg);
}
function PrefixIcon(props) {
  return /*#__PURE__*/React.createElement(Icon, _extends({}, props, {
    slot: "prefix"
  }));
}
function SuffixIcon(props) {
  return /*#__PURE__*/React.createElement(Icon, _extends({}, props, {
    slot: "suffix"
  }));
}
const glyphs = {
  check: "M21.0843 4.18854C21.5325 4.51124 21.6342 5.13618 21.3115 5.58438L11.3115 19.0844C11.1361 19.3281 10.8604 19.48 10.5607 19.4982C10.2609 19.5164 9.96888 19.399 9.7652 19.1784L2.7652 11.6784C2.3906 11.2725 2.4159 10.6399 2.82172 10.2653C3.22755 9.89067 3.8602 9.91597 4.23481 10.3218L10.4041 16.9219L19.6885 4.41577C20.0112 3.96757 20.6361 3.86584 21.0843 4.18854Z",
  minus: "M2 12C2 11.4477 2.44772 11 3 11H21C21.5523 11 22 11.4477 22 12C22 12.5523 21.5523 13 21 13H3C2.44772 13 2 12.5523 2 12Z",
  chevronLeft: "M16.66 3.22988C16.96 3.52988 16.96 4.01988 16.66 4.31988L8.97999 11.9999L16.66 19.6799C16.96 19.9799 16.96 20.4699 16.66 20.7699C16.36 21.0699 15.87 21.0699 15.57 20.7699L7.33999 12.5499C7.03999 12.2499 7.03999 11.7599 7.33999 11.4599L15.56 3.22988C15.86 2.92988 16.35 2.92988 16.65 3.22988H16.66Z",
  chevronRight: "M7.34 3.23c-.3.3-.3.79 0 1.09L15.02 12l-7.68 7.68c-.3.3-.3.79 0 1.09.3.3.79.3 1.09 0l8.23-8.22c.3-.3.3-.79 0-1.09L8.44 3.23c-.3-.3-.79-.3-1.09 0Z",
  close: "M3.73 3.73c.3-.3.79-.3 1.09 0L12 10.91l7.18-7.18c.3-.3.79-.3 1.09 0 .3.3.3.79 0 1.09L13.09 12l7.18 7.18c.3.3.3.79 0 1.09-.3.3-.79.3-1.09 0L12 13.09l-7.18 7.18c-.3.3-.79.3-1.09 0-.3-.3-.3-.79 0-1.09L10.91 12 3.73 4.82c-.3-.3-.3-.79 0-1.09Z"
};
function Glyph({
  name,
  className,
  ...rest
}) {
  return /*#__PURE__*/React.createElement("svg", _extends({
    viewBox: "0 0 24 24",
    fill: "currentColor",
    "aria-hidden": "true",
    className: className
  }, rest), /*#__PURE__*/React.createElement("path", {
    d: glyphs[name]
  }));
}
Object.assign(__ds_scope, { Icon, PrefixIcon, SuffixIcon, glyphs, Glyph });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/Icon.jsx", error: String((e && e.message) || e) }); }

// components/display/Avatar.jsx
try { (() => {
const cx = (...a) => a.filter(Boolean).join(" ");
const rc = (b, v, pairs) => {
  const o = [b];
  for (const k in v || {}) if (v[k] != null && v[k] !== false) o.push(b + "--" + k + "_" + v[k]);
  for (const p of pairs || []) if (v[p[0]] != null && v[p[1]] != null) o.push(b + "--" + p[0] + "_" + v[p[0]] + "-" + p[1] + "_" + v[p[1]]);
  return o.join(" ");
};
const da = on => on ? "" : undefined;
function Avatar({
  src,
  alt = "",
  size = "48",
  fallback,
  badge,
  className,
  style
}) {
  const s = String(size);
  return /*#__PURE__*/React.createElement("span", {
    className: cx(rc("seed-avatar__root", {
      size: s,
      badgeMask: badge ? "circle" : "none"
    }), className),
    style: style
  }, src ? /*#__PURE__*/React.createElement("img", {
    className: "seed-avatar__image",
    "data-loading-state": "loaded",
    src: src,
    alt: alt
  }) : /*#__PURE__*/React.createElement("span", {
    className: "seed-avatar__fallback",
    "data-loading-state": "error",
    style: {
      display: "flex",
      width: "100%",
      height: "100%",
      alignItems: "center",
      justifyContent: "center",
      borderRadius: "9999px",
      background: "var(--seed-color-palette-gray-300)",
      color: "var(--seed-color-fg-neutral-subtle)",
      fontWeight: 700,
      overflow: "hidden"
    }
  }, fallback), badge && /*#__PURE__*/React.createElement("span", {
    className: rc("seed-avatar__badge", {
      size: s,
      badgeMask: "circle"
    })
  }, badge));
}
function AvatarStack({
  size = "36",
  children,
  className,
  style
}) {
  return /*#__PURE__*/React.createElement("span", {
    className: cx("seed-avatar-stack__root", className),
    style: {
      display: "inline-flex",
      ...style
    }
  }, React.Children.map(children, (c, i) => /*#__PURE__*/React.createElement("span", {
    style: {
      marginLeft: i ? -Number(size) * 0.25 : 0,
      display: "inline-flex",
      borderRadius: 9999,
      boxShadow: "0 0 0 2px var(--seed-color-bg-layer-default)"
    }
  }, c)));
}
Object.assign(__ds_scope, { Avatar, AvatarStack });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/display/Avatar.jsx", error: String((e && e.message) || e) }); }

// components/display/Badge.jsx
try { (() => {
const cx = (...a) => a.filter(Boolean).join(" ");
const rc = (b, v, pairs) => {
  const o = [b];
  for (const k in v || {}) if (v[k] != null && v[k] !== false) o.push(b + "--" + k + "_" + v[k]);
  for (const p of pairs || []) if (v[p[0]] != null && v[p[1]] != null) o.push(b + "--" + p[0] + "_" + v[p[0]] + "-" + p[1] + "_" + v[p[1]]);
  return o.join(" ");
};
const da = on => on ? "" : undefined;
function Badge({
  tone = "neutral",
  variant = "weak",
  size = "medium",
  className,
  style,
  children
}) {
  return /*#__PURE__*/React.createElement("span", {
    className: cx(rc("seed-badge__root", {
      size,
      variant
    }), "seed-badge__root--tone_" + tone + "-variant_" + variant, className),
    style: style
  }, /*#__PURE__*/React.createElement("span", {
    className: "seed-badge__label"
  }, children));
}
Object.assign(__ds_scope, { Badge });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/display/Badge.jsx", error: String((e && e.message) || e) }); }

// components/display/Divider.jsx
try { (() => {
function Divider({
  orientation = "horizontal",
  thickness = 1,
  color = "var(--seed-color-stroke-neutral-muted)",
  inset = 0,
  style
}) {
  const h = orientation === "horizontal";
  return /*#__PURE__*/React.createElement("hr", {
    "aria-orientation": orientation,
    style: {
      border: 0,
      margin: h ? "0 " + inset + "px" : 0,
      flexShrink: 0,
      background: color,
      ...(h ? {
        height: thickness,
        alignSelf: "stretch"
      } : {
        width: thickness,
        alignSelf: "stretch",
        height: "auto"
      }),
      ...style
    }
  });
}
Object.assign(__ds_scope, { Divider });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/display/Divider.jsx", error: String((e && e.message) || e) }); }

// components/display/MannerTempBadge.jsx
try { (() => {
const cx = (...a) => a.filter(Boolean).join(" ");
const rc = (b, v, pairs) => {
  const o = [b];
  for (const k in v || {}) if (v[k] != null && v[k] !== false) o.push(b + "--" + k + "_" + v[k]);
  for (const p of pairs || []) if (v[p[0]] != null && v[p[1]] != null) o.push(b + "--" + p[0] + "_" + v[p[0]] + "-" + p[1] + "_" + v[p[1]]);
  return o.join(" ");
};
const da = on => on ? "" : undefined;
const B = [-Infinity, 30, 36, 36.5, 37, 40, 45, 55, 65, 80, Infinity];
function mannerTempToLevel(t) {
  for (let i = 0; i < B.length - 1; i++) if (t >= B[i] && t < B[i + 1]) return "l" + (i + 1);
  return "l1";
}
function MannerTempBadge({
  temperature,
  level,
  className,
  style
}) {
  return /*#__PURE__*/React.createElement("span", {
    className: cx(rc("seed-manner-temp-badge", {
      level: level || mannerTempToLevel(temperature)
    }), className),
    style: style
  }, temperature, "\xB0C");
}
function MannerTemp({
  temperature,
  level,
  className,
  style
}) {
  return /*#__PURE__*/React.createElement("span", {
    className: cx(rc("seed-manner-temp", {
      level: level || mannerTempToLevel(temperature)
    }), className),
    style: style
  }, temperature, "\xB0C");
}
Object.assign(__ds_scope, { mannerTempToLevel, MannerTempBadge, MannerTemp });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/display/MannerTempBadge.jsx", error: String((e && e.message) || e) }); }

// components/display/NotificationBadge.jsx
try { (() => {
const cx = (...a) => a.filter(Boolean).join(" ");
const rc = (b, v, pairs) => {
  const o = [b];
  for (const k in v || {}) if (v[k] != null && v[k] !== false) o.push(b + "--" + k + "_" + v[k]);
  for (const p of pairs || []) if (v[p[0]] != null && v[p[1]] != null) o.push(b + "--" + p[0] + "_" + v[p[0]] + "-" + p[1] + "_" + v[p[1]]);
  return o.join(" ");
};
const da = on => on ? "" : undefined;
function NotificationBadge({
  size,
  attach,
  className,
  style,
  children
}) {
  const sz = size || (children != null ? "large" : "small");
  const badge = /*#__PURE__*/React.createElement("span", {
    className: cx(rc("seed-notification-badge", {
      size: sz
    }), className),
    style: attach ? undefined : style
  }, sz === "large" ? children : null);
  if (!attach) return badge;
  return /*#__PURE__*/React.createElement("span", {
    className: rc("seed-notification-badge-positioner", {
      size: sz,
      attach
    }, [["size", "attach"]]),
    style: style
  }, badge);
}
Object.assign(__ds_scope, { NotificationBadge });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/display/NotificationBadge.jsx", error: String((e && e.message) || e) }); }

// components/display/ProgressCircle.jsx
try { (() => {
const cx = (...a) => a.filter(Boolean).join(" ");
const rc = (b, v, pairs) => {
  const o = [b];
  for (const k in v || {}) if (v[k] != null && v[k] !== false) o.push(b + "--" + k + "_" + v[k]);
  for (const p of pairs || []) if (v[p[0]] != null && v[p[1]] != null) o.push(b + "--" + p[0] + "_" + v[p[0]] + "-" + p[1] + "_" + v[p[1]]);
  return o.join(" ");
};
const da = on => on ? "" : undefined;
function ProgressCircle({
  value,
  tone = "neutral",
  size = "40",
  className,
  style
}) {
  const [s, t] = {
    "24": [24, 3],
    "40": [40, 5],
    inherit: [16, 2]
  }[String(size)] || [40, 5];
  const r = (s - t) / 2,
    c = 2 * Math.PI * r,
    ind = value == null;
  const state = ind ? "indeterminate" : value >= 100 ? "complete" : "loading";
  return /*#__PURE__*/React.createElement("svg", {
    className: cx(rc("seed-progress-circle__root", {
      tone,
      size
    }), className),
    "data-progress-state": state,
    width: s,
    height: s,
    viewBox: "0 0 " + s + " " + s,
    style: style,
    role: "progressbar",
    "aria-valuenow": ind ? undefined : value
  }, /*#__PURE__*/React.createElement("circle", {
    className: "seed-progress-circle__track",
    cx: s / 2,
    cy: s / 2,
    r: r,
    fill: "none",
    strokeWidth: t
  }), /*#__PURE__*/React.createElement("circle", {
    className: "seed-progress-circle__range",
    "data-progress-state": state,
    cx: s / 2,
    cy: s / 2,
    r: r,
    fill: "none",
    strokeWidth: t,
    transform: "rotate(-90 " + s / 2 + " " + s / 2 + ")",
    style: {
      "--circumference": c + "px",
      strokeDasharray: ind ? undefined : c * value / 100 + " " + c
    }
  }));
}
Object.assign(__ds_scope, { ProgressCircle });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/display/ProgressCircle.jsx", error: String((e && e.message) || e) }); }

// components/actions/ActionButton.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
const cx = (...a) => a.filter(Boolean).join(" ");
const rc = (b, v, pairs) => {
  const o = [b];
  for (const k in v || {}) if (v[k] != null && v[k] !== false) o.push(b + "--" + k + "_" + v[k]);
  for (const p of pairs || []) if (v[p[0]] != null && v[p[1]] != null) o.push(b + "--" + p[0] + "_" + v[p[0]] + "-" + p[1] + "_" + v[p[1]]);
  return o.join(" ");
};
const da = on => on ? "" : undefined;
const SCALE = {
  xsmall: 0.9375,
  small: 0.944,
  medium: 0.95,
  large: 0.96
};
function ActionButton({
  variant = "brandSolid",
  size = "medium",
  layout = "withText",
  loading = false,
  disabled = false,
  flexGrow,
  color,
  className,
  style,
  children,
  ...rest
}) {
  const st = {
    "--seed-feedback-scale": SCALE[size],
    ...(flexGrow ? {
      "--seed-box-flex-grow": flexGrow === true ? 1 : flexGrow
    } : {}),
    ...(color ? {
      "--seed-box-color": color
    } : {}),
    ...style
  };
  return /*#__PURE__*/React.createElement("button", _extends({
    type: "button",
    className: cx(rc("seed-action-button", {
      variant,
      size,
      layout
    }, [["size", "layout"]]), className),
    disabled: disabled,
    "data-disabled": da(disabled),
    "data-loading": da(loading),
    "aria-busy": loading || undefined,
    style: st
  }, rest), loading ? /*#__PURE__*/React.createElement("span", {
    style: {
      visibility: "hidden",
      display: "contents"
    }
  }, children) : children, loading && /*#__PURE__*/React.createElement("span", {
    className: "seed-loading-indicator"
  }, /*#__PURE__*/React.createElement(__ds_scope.ProgressCircle, {
    size: "inherit",
    tone: "inherit"
  })));
}
Object.assign(__ds_scope, { ActionButton });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/actions/ActionButton.jsx", error: String((e && e.message) || e) }); }

// components/display/Skeleton.jsx
try { (() => {
const cx = (...a) => a.filter(Boolean).join(" ");
const rc = (b, v, pairs) => {
  const o = [b];
  for (const k in v || {}) if (v[k] != null && v[k] !== false) o.push(b + "--" + k + "_" + v[k]);
  for (const p of pairs || []) if (v[p[0]] != null && v[p[1]] != null) o.push(b + "--" + p[0] + "_" + v[p[0]] + "-" + p[1] + "_" + v[p[1]]);
  return o.join(" ");
};
const da = on => on ? "" : undefined;
function Skeleton({
  width = "100%",
  height = 16,
  radius = "8",
  tone = "neutral",
  className,
  style
}) {
  return /*#__PURE__*/React.createElement("div", {
    "aria-hidden": "true",
    className: cx(rc("seed-skeleton", {
      radius: String(radius),
      tone
    }), className),
    style: {
      width,
      height,
      ...style
    }
  });
}
Object.assign(__ds_scope, { Skeleton });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/display/Skeleton.jsx", error: String((e && e.message) || e) }); }

// components/display/TagGroup.jsx
try { (() => {
const cx = (...a) => a.filter(Boolean).join(" ");
const rc = (b, v, pairs) => {
  const o = [b];
  for (const k in v || {}) if (v[k] != null && v[k] !== false) o.push(b + "--" + k + "_" + v[k]);
  for (const p of pairs || []) if (v[p[0]] != null && v[p[1]] != null) o.push(b + "--" + p[0] + "_" + v[p[0]] + "-" + p[1] + "_" + v[p[1]]);
  return o.join(" ");
};
const da = on => on ? "" : undefined;
function TagGroup({
  tags = [],
  size = "t3",
  weight = "regular",
  tone = "neutralSubtle",
  separator = "·",
  truncate = false,
  className,
  style
}) {
  return /*#__PURE__*/React.createElement("span", {
    className: cx(rc("seed-tag-group__root", {
      truncate: truncate ? "true" : null
    }), className),
    style: {
      fontSize: "var(--seed-font-size-" + size + ")",
      lineHeight: "var(--seed-line-height-" + size + ")",
      ...style
    }
  }, tags.map((t, i) => /*#__PURE__*/React.createElement(React.Fragment, {
    key: i
  }, i > 0 && /*#__PURE__*/React.createElement("span", {
    className: rc("seed-tag-group__separator", {
      size
    }),
    "aria-hidden": "true"
  }, " ", separator, " "), /*#__PURE__*/React.createElement("span", {
    className: rc("seed-tag-group-item__root", {
      size,
      weight,
      tone
    }),
    style: {
      whiteSpace: "nowrap"
    }
  }, /*#__PURE__*/React.createElement("span", {
    className: rc("seed-tag-group-item__label", {
      size,
      weight,
      tone
    }),
    style: {
      whiteSpace: truncate ? undefined : "nowrap"
    }
  }, t)))));
}
Object.assign(__ds_scope, { TagGroup });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/display/TagGroup.jsx", error: String((e && e.message) || e) }); }

// components/display/Text.jsx
try { (() => {
const cx = (...a) => a.filter(Boolean).join(" ");
const rc = (b, v, pairs) => {
  const o = [b];
  for (const k in v || {}) if (v[k] != null && v[k] !== false) o.push(b + "--" + k + "_" + v[k]);
  for (const p of pairs || []) if (v[p[0]] != null && v[p[1]] != null) o.push(b + "--" + p[0] + "_" + v[p[0]] + "-" + p[1] + "_" + v[p[1]]);
  return o.join(" ");
};
const da = on => on ? "" : undefined;
function Text({
  as = "span",
  textStyle = "t5Regular",
  color,
  maxLines,
  align,
  className,
  style,
  children
}) {
  const Tag = as;
  const ml = maxLines == null ? undefined : maxLines === 1 ? "single" : "multi";
  const st = {
    ...(color ? {
      "--seed-text-color": color
    } : {}),
    ...(align ? {
      "--seed-text-align": align
    } : {}),
    ...(ml === "multi" ? {
      "--seed-max-lines": maxLines
    } : {}),
    ...style
  };
  return /*#__PURE__*/React.createElement(Tag, {
    className: cx(rc("seed-text", {
      textStyle,
      maxLines: ml
    }), className),
    style: st
  }, children);
}
Object.assign(__ds_scope, { Text });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/display/Text.jsx", error: String((e && e.message) || e) }); }

// components/display/ResultSection.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/** Empty / result state block (registry snippet result-section). */
function ResultSection({
  size = "large",
  asset,
  title,
  description,
  primaryActionProps,
  secondaryActionProps,
  style
}) {
  const lg = size === "large";
  return /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      flexDirection: "column",
      justifyContent: "center",
      alignItems: "center",
      padding: "16px 48px",
      flexGrow: 1,
      ...style
    }
  }, asset, /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      flexDirection: "column",
      gap: lg ? 12 : 8,
      paddingBottom: lg ? 28 : 24
    }
  }, /*#__PURE__*/React.createElement(__ds_scope.Text, {
    align: "center",
    textStyle: lg ? "t8Bold" : "t5Bold",
    color: "var(--seed-color-fg-neutral)",
    style: {
      whiteSpace: "pre-line"
    }
  }, title), /*#__PURE__*/React.createElement(__ds_scope.Text, {
    align: "center",
    textStyle: lg ? "t5Regular" : "t4Regular",
    color: "var(--seed-color-fg-neutral-muted)",
    style: {
      whiteSpace: "pre-line"
    }
  }, description)), (primaryActionProps || secondaryActionProps) && /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      flexDirection: "column",
      alignItems: "center",
      gap: 20
    }
  }, primaryActionProps && /*#__PURE__*/React.createElement(__ds_scope.ActionButton, _extends({
    variant: "neutralWeak",
    size: "medium"
  }, primaryActionProps)), secondaryActionProps && /*#__PURE__*/React.createElement(__ds_scope.ActionButton, _extends({
    variant: "ghost",
    size: "small"
  }, secondaryActionProps))));
}
Object.assign(__ds_scope, { ResultSection });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/display/ResultSection.jsx", error: String((e && e.message) || e) }); }

// components/feedback/Callout.jsx
try { (() => {
const cx = (...a) => a.filter(Boolean).join(" ");
const rc = (b, v, pairs) => {
  const o = [b];
  for (const k in v || {}) if (v[k] != null && v[k] !== false) o.push(b + "--" + k + "_" + v[k]);
  for (const p of pairs || []) if (v[p[0]] != null && v[p[1]] != null) o.push(b + "--" + p[0] + "_" + v[p[0]] + "-" + p[1] + "_" + v[p[1]]);
  return o.join(" ");
};
const da = on => on ? "" : undefined;
function Callout({
  tone = "neutral",
  title,
  description,
  prefixIcon,
  linkLabel,
  onLinkClick,
  onClose,
  onClick,
  className,
  style
}) {
  const Root = onClick ? "button" : "div";
  const t = {
    tone
  };
  return /*#__PURE__*/React.createElement(Root, {
    type: onClick ? "button" : undefined,
    onClick: onClick,
    className: cx(rc("seed-callout__root", t), className),
    style: style
  }, prefixIcon && /*#__PURE__*/React.createElement(__ds_scope.PrefixIcon, {
    src: prefixIcon
  }), /*#__PURE__*/React.createElement("div", {
    className: "seed-callout__content"
  }, title && /*#__PURE__*/React.createElement("span", {
    className: rc("seed-callout__title", t)
  }, title), /*#__PURE__*/React.createElement("span", {
    className: rc("seed-callout__description", t)
  }, description), linkLabel && /*#__PURE__*/React.createElement("button", {
    type: "button",
    className: rc("seed-callout__link", t),
    onClick: onLinkClick
  }, linkLabel)), onClick && /*#__PURE__*/React.createElement(__ds_scope.SuffixIcon, {
    svg: /*#__PURE__*/React.createElement("svg", {
      viewBox: "0 0 24 24",
      fill: "currentColor",
      width: "100%",
      height: "100%"
    }, /*#__PURE__*/React.createElement("path", {
      d: "M7.34 3.23c-.3.3-.3.79 0 1.09L15.02 12l-7.68 7.68c-.3.3-.3.79 0 1.09.3.3.79.3 1.09 0l8.23-8.22c.3-.3.3-.79 0-1.09L8.44 3.23c-.3-.3-.79-.3-1.09 0Z"
    }))
  }), onClose && /*#__PURE__*/React.createElement("button", {
    type: "button",
    "aria-label": "\uB2EB\uAE30",
    className: rc("seed-callout__closeButton", t),
    onClick: onClose
  }, /*#__PURE__*/React.createElement(__ds_scope.SuffixIcon, {
    svg: /*#__PURE__*/React.createElement("svg", {
      viewBox: "0 0 24 24",
      fill: "currentColor",
      width: "100%",
      height: "100%"
    }, /*#__PURE__*/React.createElement("path", {
      d: "M3.73 3.73c.3-.3.79-.3 1.09 0L12 10.91l7.18-7.18c.3-.3.79-.3 1.09 0 .3.3.3.79 0 1.09L13.09 12l7.18 7.18c.3.3.3.79 0 1.09-.3.3-.79.3-1.09 0L12 13.09l-7.18 7.18c-.3.3-.79.3-1.09 0-.3-.3-.3-.79 0-1.09L10.91 12 3.73 4.82c-.3-.3-.3-.79 0-1.09Z"
    }))
  })));
}
Object.assign(__ds_scope, { Callout });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/feedback/Callout.jsx", error: String((e && e.message) || e) }); }

// components/feedback/HelpBubble.jsx
try { (() => {
const cx = (...a) => a.filter(Boolean).join(" ");
const rc = (b, v, pairs) => {
  const o = [b];
  for (const k in v || {}) if (v[k] != null && v[k] !== false) o.push(b + "--" + k + "_" + v[k]);
  for (const p of pairs || []) if (v[p[0]] != null && v[p[1]] != null) o.push(b + "--" + p[0] + "_" + v[p[0]] + "-" + p[1] + "_" + v[p[1]]);
  return o.join(" ");
};
const da = on => on ? "" : undefined;
function HelpBubble({
  title,
  description,
  onClose,
  placement = "bottom",
  arrowOffset = 24,
  className,
  style
}) {
  const up = placement === "bottom";
  return /*#__PURE__*/React.createElement("div", {
    className: cx("seed-help-bubble__content", className),
    "data-state": "open",
    "data-open": "",
    style: {
      position: "relative",
      display: "inline-flex",
      ...style
    }
  }, /*#__PURE__*/React.createElement("svg", {
    className: "seed-help-bubble__arrow",
    width: "14",
    height: "8",
    viewBox: "0 0 14 8",
    style: {
      position: "absolute",
      left: arrowOffset,
      [up ? "bottom" : "top"]: "100%",
      transform: up ? "rotate(180deg)" : undefined
    }
  }, /*#__PURE__*/React.createElement("path", {
    className: "seed-help-bubble__arrowTip",
    d: "M0 0h14L8.4 6.4a2 2 0 0 1-2.8 0L0 0Z",
    fill: "var(--seed-color-bg-neutral-inverted)"
  })), /*#__PURE__*/React.createElement("div", {
    className: "seed-help-bubble__body"
  }, title && /*#__PURE__*/React.createElement("span", {
    className: "seed-help-bubble__title"
  }, title), description && /*#__PURE__*/React.createElement("span", {
    className: "seed-help-bubble__description"
  }, description)), onClose && /*#__PURE__*/React.createElement("button", {
    type: "button",
    "aria-label": "\uB2EB\uAE30",
    className: "seed-help-bubble__closeButton",
    onClick: onClose
  }, /*#__PURE__*/React.createElement("svg", {
    viewBox: "0 0 24 24",
    fill: "currentColor",
    width: "14",
    height: "14"
  }, /*#__PURE__*/React.createElement("path", {
    d: "M3.73 3.73c.3-.3.79-.3 1.09 0L12 10.91l7.18-7.18c.3-.3.79-.3 1.09 0 .3.3.3.79 0 1.09L13.09 12l7.18 7.18c.3.3.3.79 0 1.09-.3.3-.79.3-1.09 0L12 13.09l-7.18 7.18c-.3.3-.79.3-1.09 0-.3-.3-.3-.79 0-1.09L10.91 12 3.73 4.82c-.3-.3-.3-.79 0-1.09Z"
  }))));
}
Object.assign(__ds_scope, { HelpBubble });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/feedback/HelpBubble.jsx", error: String((e && e.message) || e) }); }

// components/feedback/PageBanner.jsx
try { (() => {
const cx = (...a) => a.filter(Boolean).join(" ");
const rc = (b, v, pairs) => {
  const o = [b];
  for (const k in v || {}) if (v[k] != null && v[k] !== false) o.push(b + "--" + k + "_" + v[k]);
  for (const p of pairs || []) if (v[p[0]] != null && v[p[1]] != null) o.push(b + "--" + p[0] + "_" + v[p[0]] + "-" + p[1] + "_" + v[p[1]]);
  return o.join(" ");
};
const da = on => on ? "" : undefined;
function PageBanner({
  tone = "neutral",
  variant = "weak",
  title,
  description,
  prefixIcon,
  buttonLabel,
  onButtonClick,
  onClose,
  className,
  style
}) {
  const k = "--tone_" + tone + "-variant_" + variant;
  return /*#__PURE__*/React.createElement("div", {
    className: cx("seed-page-banner__root seed-page-banner__root" + k, className),
    style: style
  }, prefixIcon && /*#__PURE__*/React.createElement(__ds_scope.PrefixIcon, {
    src: prefixIcon
  }), /*#__PURE__*/React.createElement("div", {
    className: "seed-page-banner__content"
  }, /*#__PURE__*/React.createElement("div", {
    className: "seed-page-banner__body"
  }, title && /*#__PURE__*/React.createElement("span", {
    className: "seed-page-banner__title seed-page-banner__title" + k
  }, title), /*#__PURE__*/React.createElement("span", {
    className: "seed-page-banner__description seed-page-banner__description" + k
  }, description)), buttonLabel && /*#__PURE__*/React.createElement("button", {
    type: "button",
    className: "seed-page-banner__button seed-page-banner__button" + k,
    onClick: onButtonClick
  }, buttonLabel)), onClose && /*#__PURE__*/React.createElement("button", {
    type: "button",
    "aria-label": "\uB2EB\uAE30",
    className: "seed-page-banner__closeButton seed-page-banner__closeButton" + k,
    onClick: onClose
  }, /*#__PURE__*/React.createElement(__ds_scope.SuffixIcon, {
    svg: /*#__PURE__*/React.createElement("svg", {
      viewBox: "0 0 24 24",
      fill: "currentColor",
      width: "100%",
      height: "100%"
    }, /*#__PURE__*/React.createElement("path", {
      d: "M3.73 3.73c.3-.3.79-.3 1.09 0L12 10.91l7.18-7.18c.3-.3.79-.3 1.09 0 .3.3.3.79 0 1.09L13.09 12l7.18 7.18c.3.3.3.79 0 1.09-.3.3-.79.3-1.09 0L12 13.09l-7.18 7.18c-.3.3-.79.3-1.09 0-.3-.3-.3-.79 0-1.09L10.91 12 3.73 4.82c-.3-.3-.3-.79 0-1.09Z"
    }))
  })));
}
Object.assign(__ds_scope, { PageBanner });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/feedback/PageBanner.jsx", error: String((e && e.message) || e) }); }

// components/feedback/Snackbar.jsx
try { (() => {
const cx = (...a) => a.filter(Boolean).join(" ");
const rc = (b, v, pairs) => {
  const o = [b];
  for (const k in v || {}) if (v[k] != null && v[k] !== false) o.push(b + "--" + k + "_" + v[k]);
  for (const p of pairs || []) if (v[p[0]] != null && v[p[1]] != null) o.push(b + "--" + p[0] + "_" + v[p[0]] + "-" + p[1] + "_" + v[p[1]]);
  return o.join(" ");
};
const da = on => on ? "" : undefined;
function Snackbar({
  message,
  variant = "default",
  actionLabel,
  onAction,
  open = true,
  className,
  style
}) {
  const icon = variant === "positive" ? "M12 2a10 10 0 1 0 0 20 10 10 0 0 0 0-20Zm4.7 7.7-5.5 5.5a1 1 0 0 1-1.4 0l-2.5-2.5a1 1 0 1 1 1.4-1.4l1.8 1.8 4.8-4.8a1 1 0 1 1 1.4 1.4Z" : variant === "critical" ? "M12 2a10 10 0 1 0 0 20 10 10 0 0 0 0-20Zm0 5a1 1 0 0 1 1 1v5a1 1 0 1 1-2 0V8a1 1 0 0 1 1-1Zm0 10.2a1.2 1.2 0 1 1 0-2.4 1.2 1.2 0 0 1 0 2.4Z" : null;
  return /*#__PURE__*/React.createElement("div", {
    role: "status",
    className: cx("seed-snackbar__root", className),
    "data-open": da(open),
    style: style
  }, /*#__PURE__*/React.createElement("div", {
    className: "seed-snackbar__content"
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      display: "flex",
      alignItems: "center",
      gap: 6
    }
  }, icon && /*#__PURE__*/React.createElement("svg", {
    className: rc("seed-snackbar__prefixIcon", {
      variant
    }),
    viewBox: "0 0 24 24",
    fill: "currentColor"
  }, /*#__PURE__*/React.createElement("path", {
    d: icon
  })), /*#__PURE__*/React.createElement("span", {
    className: "seed-snackbar__message"
  }, message)), actionLabel && /*#__PURE__*/React.createElement("button", {
    type: "button",
    className: "seed-snackbar__actionButton",
    onClick: onAction
  }, actionLabel)));
}
Object.assign(__ds_scope, { Snackbar });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/feedback/Snackbar.jsx", error: String((e && e.message) || e) }); }

// components/forms/Checkbox.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
const cx = (...a) => a.filter(Boolean).join(" ");
const rc = (b, v, pairs) => {
  const o = [b];
  for (const k in v || {}) if (v[k] != null && v[k] !== false) o.push(b + "--" + k + "_" + v[k]);
  for (const p of pairs || []) if (v[p[0]] != null && v[p[1]] != null) o.push(b + "--" + p[0] + "_" + v[p[0]] + "-" + p[1] + "_" + v[p[1]]);
  return o.join(" ");
};
const da = on => on ? "" : undefined;
function Checkmark({
  checked,
  indeterminate,
  disabled,
  variant = "square",
  tone = "brand",
  size = "medium",
  className
}) {
  const v = {
      variant,
      tone,
      size
    },
    on = checked || indeterminate;
  const st = {
    "data-checked": da(on),
    "data-indeterminate": da(indeterminate),
    "data-disabled": da(disabled)
  };
  const showIcon = on || variant === "ghost";
  return /*#__PURE__*/React.createElement("div", _extends({
    className: cx(rc("seed-checkmark__root", v, [["variant", "tone"]]), className)
  }, st, {
    style: {
      "--seed-feedback-scale": 0.92
    }
  }), showIcon && /*#__PURE__*/React.createElement(__ds_scope.Glyph, _extends({
    name: indeterminate ? "minus" : "check",
    className: rc("seed-checkmark__icon", v, [["variant", "tone"], ["size", "variant"]])
  }, st)));
}
function Checkbox({
  label,
  checked,
  defaultChecked = false,
  indeterminate,
  onCheckedChange,
  disabled,
  size = "medium",
  weight = "regular",
  variant = "square",
  tone = "brand",
  className,
  style
}) {
  const [inner, setInner] = React.useState(defaultChecked);
  const on = checked ?? inner;
  const change = e => {
    if (checked == null) setInner(e.target.checked);
    onCheckedChange && onCheckedChange(e.target.checked);
  };
  return /*#__PURE__*/React.createElement("label", {
    className: cx(rc("seed-checkbox__root", {
      size
    }), className),
    "data-disabled": da(disabled),
    style: {
      position: "relative",
      ...style
    }
  }, /*#__PURE__*/React.createElement(Checkmark, {
    checked: on,
    indeterminate: indeterminate,
    disabled: disabled,
    variant: variant,
    tone: tone,
    size: size
  }), label != null && /*#__PURE__*/React.createElement("span", {
    className: rc("seed-checkbox__label", {
      weight,
      size
    }),
    "data-disabled": da(disabled)
  }, label), /*#__PURE__*/React.createElement("input", {
    type: "checkbox",
    checked: on,
    disabled: disabled,
    onChange: change,
    style: {
      position: "absolute",
      opacity: 0,
      width: 1,
      height: 1,
      margin: 0,
      pointerEvents: "none"
    }
  }));
}
Object.assign(__ds_scope, { Checkmark, Checkbox });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/forms/Checkbox.jsx", error: String((e && e.message) || e) }); }

// components/forms/Chip.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
const cx = (...a) => a.filter(Boolean).join(" ");
const rc = (b, v, pairs) => {
  const o = [b];
  for (const k in v || {}) if (v[k] != null && v[k] !== false) o.push(b + "--" + k + "_" + v[k]);
  for (const p of pairs || []) if (v[p[0]] != null && v[p[1]] != null) o.push(b + "--" + p[0] + "_" + v[p[0]] + "-" + p[1] + "_" + v[p[1]]);
  return o.join(" ");
};
const da = on => on ? "" : undefined;
function Chip({
  variant = "solid",
  size = "medium",
  checked,
  defaultChecked = false,
  onCheckedChange,
  disabled,
  prefixIcon,
  suffixIcon,
  className,
  style,
  children
}) {
  const [inner, setInner] = React.useState(defaultChecked);
  const on = checked ?? inner;
  const v = {
    variant,
    size
  };
  const st = {
    "data-checked": da(on),
    "data-disabled": da(disabled)
  };
  return /*#__PURE__*/React.createElement("button", _extends({
    type: "button",
    role: "checkbox",
    "aria-checked": on,
    disabled: disabled,
    className: cx(rc("seed-chip__root", v), "seed-chip__root--size_" + size + "-layout_withText", className)
  }, st, {
    onClick: () => {
      if (checked == null) setInner(!on);
      onCheckedChange && onCheckedChange(!on);
    },
    style: {
      "--seed-feedback-scale": 0.95,
      ...style
    }
  }), prefixIcon && /*#__PURE__*/React.createElement(__ds_scope.Icon, {
    slot: "none",
    src: prefixIcon,
    className: rc("seed-chip__prefixIcon", v)
  }), /*#__PURE__*/React.createElement("span", _extends({
    className: rc("seed-chip__label", v)
  }, st), children), suffixIcon && /*#__PURE__*/React.createElement(__ds_scope.Icon, {
    slot: "none",
    src: suffixIcon,
    className: rc("seed-chip__suffixIcon", v)
  }));
}
Object.assign(__ds_scope, { Chip });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/forms/Chip.jsx", error: String((e && e.message) || e) }); }

// components/forms/QuantityPicker.jsx
try { (() => {
const cx = (...a) => a.filter(Boolean).join(" ");
const rc = (b, v, pairs) => {
  const o = [b];
  for (const k in v || {}) if (v[k] != null && v[k] !== false) o.push(b + "--" + k + "_" + v[k]);
  for (const p of pairs || []) if (v[p[0]] != null && v[p[1]] != null) o.push(b + "--" + p[0] + "_" + v[p[0]] + "-" + p[1] + "_" + v[p[1]]);
  return o.join(" ");
};
const da = on => on ? "" : undefined;
function QuantityPicker({
  value,
  defaultValue = 1,
  min = 0,
  max = 99,
  step = 1,
  onValueChange,
  size = "medium",
  disabled,
  className,
  style
}) {
  const [inner, setInner] = React.useState(defaultValue);
  const v = value ?? inner;
  const set = n => {
    n = Math.min(max, Math.max(min, n));
    if (value == null) setInner(n);
    onValueChange && onValueChange(n);
  };
  const k = {
    size
  };
  const ico = d => /*#__PURE__*/React.createElement("svg", {
    viewBox: "0 0 24 24",
    fill: "currentColor",
    width: "100%",
    height: "100%"
  }, /*#__PURE__*/React.createElement("path", {
    d: d
  }));
  return /*#__PURE__*/React.createElement("div", {
    className: cx(rc("seed-quantity-picker__root", k), className),
    "data-disabled": da(disabled),
    style: style
  }, /*#__PURE__*/React.createElement("button", {
    type: "button",
    "aria-label": "\uBE7C\uAE30",
    className: rc("seed-quantity-picker__decrementButton", k),
    disabled: disabled || v <= min,
    "data-disabled": da(disabled || v <= min),
    onClick: () => set(v - step)
  }, /*#__PURE__*/React.createElement("span", {
    className: rc("seed-quantity-picker__decrementIcon", k)
  }, ico("M2 12a1 1 0 0 1 1-1h18a1 1 0 1 1 0 2H3a1 1 0 0 1-1-1Z"))), /*#__PURE__*/React.createElement("span", {
    className: rc("seed-quantity-picker__valueDisplay", k)
  }, /*#__PURE__*/React.createElement("span", {
    className: "seed-quantity-picker__valueDisplayText"
  }, v)), /*#__PURE__*/React.createElement("span", {
    className: rc("seed-quantity-picker__divider", k)
  }), /*#__PURE__*/React.createElement("button", {
    type: "button",
    "aria-label": "\uB354\uD558\uAE30",
    className: rc("seed-quantity-picker__incrementButton", k),
    disabled: disabled || v >= max,
    "data-disabled": da(disabled || v >= max),
    onClick: () => set(v + step)
  }, /*#__PURE__*/React.createElement("span", {
    className: rc("seed-quantity-picker__incrementIcon", k)
  }, ico("M12 2a1 1 0 0 1 1 1v8h8a1 1 0 1 1 0 2h-8v8a1 1 0 1 1-2 0v-8H3a1 1 0 1 1 0-2h8V3a1 1 0 0 1 1-1Z"))));
}
Object.assign(__ds_scope, { QuantityPicker });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/forms/QuantityPicker.jsx", error: String((e && e.message) || e) }); }

// components/forms/RadioGroup.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
const cx = (...a) => a.filter(Boolean).join(" ");
const rc = (b, v, pairs) => {
  const o = [b];
  for (const k in v || {}) if (v[k] != null && v[k] !== false) o.push(b + "--" + k + "_" + v[k]);
  for (const p of pairs || []) if (v[p[0]] != null && v[p[1]] != null) o.push(b + "--" + p[0] + "_" + v[p[0]] + "-" + p[1] + "_" + v[p[1]]);
  return o.join(" ");
};
const da = on => on ? "" : undefined;
function Radiomark({
  checked,
  disabled,
  tone = "brand",
  size = "medium"
}) {
  const st = {
    "data-checked": da(checked),
    "data-disabled": da(disabled)
  };
  return /*#__PURE__*/React.createElement("div", _extends({
    className: rc("seed-radiomark__root", {
      tone,
      size
    })
  }, st), /*#__PURE__*/React.createElement("svg", _extends({
    viewBox: "0 0 24 24",
    className: rc("seed-radiomark__icon", {
      tone,
      size
    })
  }, st), /*#__PURE__*/React.createElement("circle", {
    cx: "12",
    cy: "12",
    r: "12",
    fill: "currentColor"
  })));
}
function RadioGroup({
  options = [],
  value,
  defaultValue,
  onValueChange,
  name = "radio",
  size = "medium",
  weight = "regular",
  tone = "brand",
  direction = "column",
  className,
  style
}) {
  const [inner, setInner] = React.useState(defaultValue);
  const cur = value ?? inner;
  const pick = v => {
    if (value == null) setInner(v);
    onValueChange && onValueChange(v);
  };
  return /*#__PURE__*/React.createElement("div", {
    role: "radiogroup",
    className: cx("seed-radio-group__root", className),
    style: {
      display: "flex",
      flexDirection: direction,
      gap: direction === "column" ? 12 : 16,
      ...style
    }
  }, options.map(o => /*#__PURE__*/React.createElement("label", {
    key: o.value,
    className: rc("seed-radio__root", {
      size
    }),
    "data-disabled": da(o.disabled),
    style: {
      position: "relative"
    }
  }, /*#__PURE__*/React.createElement(Radiomark, {
    checked: cur === o.value,
    disabled: o.disabled,
    tone: tone,
    size: size
  }), /*#__PURE__*/React.createElement("span", {
    className: rc("seed-radio__label", {
      weight,
      size
    })
  }, o.label), /*#__PURE__*/React.createElement("input", {
    type: "radio",
    name: name,
    checked: cur === o.value,
    disabled: o.disabled,
    onChange: () => pick(o.value),
    style: {
      position: "absolute",
      opacity: 0,
      width: 1,
      height: 1,
      margin: 0
    }
  }))));
}
Object.assign(__ds_scope, { Radiomark, RadioGroup });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/forms/RadioGroup.jsx", error: String((e && e.message) || e) }); }

// components/forms/SegmentedControl.jsx
try { (() => {
const cx = (...a) => a.filter(Boolean).join(" ");
const rc = (b, v, pairs) => {
  const o = [b];
  for (const k in v || {}) if (v[k] != null && v[k] !== false) o.push(b + "--" + k + "_" + v[k]);
  for (const p of pairs || []) if (v[p[0]] != null && v[p[1]] != null) o.push(b + "--" + p[0] + "_" + v[p[0]] + "-" + p[1] + "_" + v[p[1]]);
  return o.join(" ");
};
const da = on => on ? "" : undefined;
function SegmentedControl({
  options = [],
  value,
  defaultValue,
  onValueChange,
  className,
  style
}) {
  const [inner, setInner] = React.useState(defaultValue ?? (options[0] && options[0].value));
  const cur = value ?? inner;
  const idx = Math.max(0, options.findIndex(o => o.value === cur));
  return /*#__PURE__*/React.createElement("div", {
    role: "radiogroup",
    className: cx("seed-segmented-control__root", className),
    style: style
  }, /*#__PURE__*/React.createElement("div", {
    className: "seed-segmented-control__indicator",
    style: {
      "--segment-index": idx,
      "--segment-count": options.length
    }
  }), options.map(o => /*#__PURE__*/React.createElement("button", {
    key: o.value,
    type: "button",
    role: "radio",
    "aria-checked": cur === o.value,
    className: "seed-segmented-control__item",
    "data-checked": da(cur === o.value),
    onClick: () => {
      if (value == null) setInner(o.value);
      onValueChange && onValueChange(o.value);
    },
    style: {
      border: 0,
      background: "transparent",
      fontFamily: "inherit"
    }
  }, o.label)));
}
Object.assign(__ds_scope, { SegmentedControl });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/forms/SegmentedControl.jsx", error: String((e && e.message) || e) }); }

// components/forms/SelectBox.jsx
try { (() => {
const cx = (...a) => a.filter(Boolean).join(" ");
const rc = (b, v, pairs) => {
  const o = [b];
  for (const k in v || {}) if (v[k] != null && v[k] !== false) o.push(b + "--" + k + "_" + v[k]);
  for (const p of pairs || []) if (v[p[0]] != null && v[p[1]] != null) o.push(b + "--" + p[0] + "_" + v[p[0]] + "-" + p[1] + "_" + v[p[1]]);
  return o.join(" ");
};
const da = on => on ? "" : undefined;
function SelectBox({
  options = [],
  type = "radio",
  value,
  defaultValue,
  onValueChange,
  layout = "horizontal",
  className,
  style
}) {
  const [inner, setInner] = React.useState(defaultValue ?? (type === "checkbox" ? [] : undefined));
  const cur = value ?? inner;
  const isOn = v => type === "checkbox" ? (cur || []).includes(v) : cur === v;
  const pick = v => {
    const n = type === "checkbox" ? isOn(v) ? cur.filter(x => x !== v) : [...(cur || []), v] : v;
    if (value == null) setInner(n);
    onValueChange && onValueChange(n);
  };
  return /*#__PURE__*/React.createElement("div", {
    className: cx("seed-select-box-group__root", className),
    style: {
      display: "flex",
      flexDirection: "column",
      gap: 12,
      ...style
    }
  }, options.map(o => /*#__PURE__*/React.createElement("label", {
    key: o.value,
    className: "seed-select-box__root",
    "data-checked": da(isOn(o.value))
  }, /*#__PURE__*/React.createElement("div", {
    className: rc("seed-select-box__trigger", {
      layout
    }),
    "data-checked": da(isOn(o.value)),
    onClick: e => {
      e.preventDefault();
      pick(o.value);
    }
  }, /*#__PURE__*/React.createElement("div", {
    className: rc("seed-select-box__content", {
      layout
    })
  }, /*#__PURE__*/React.createElement("div", {
    className: "seed-select-box__body"
  }, /*#__PURE__*/React.createElement("span", {
    className: "seed-select-box__label"
  }, o.label), o.description && /*#__PURE__*/React.createElement("span", {
    className: "seed-select-box__description"
  }, o.description))), type === "checkbox" ? /*#__PURE__*/React.createElement(__ds_scope.Checkmark, {
    checked: isOn(o.value)
  }) : /*#__PURE__*/React.createElement(__ds_scope.Radiomark, {
    checked: isOn(o.value)
  })))));
}
Object.assign(__ds_scope, { SelectBox });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/forms/SelectBox.jsx", error: String((e && e.message) || e) }); }

// components/forms/Switch.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
const cx = (...a) => a.filter(Boolean).join(" ");
const rc = (b, v, pairs) => {
  const o = [b];
  for (const k in v || {}) if (v[k] != null && v[k] !== false) o.push(b + "--" + k + "_" + v[k]);
  for (const p of pairs || []) if (v[p[0]] != null && v[p[1]] != null) o.push(b + "--" + p[0] + "_" + v[p[0]] + "-" + p[1] + "_" + v[p[1]]);
  return o.join(" ");
};
const da = on => on ? "" : undefined;
function Switch({
  label,
  checked,
  defaultChecked = false,
  onCheckedChange,
  disabled,
  size = "32",
  tone = "brand",
  className,
  style
}) {
  const [inner, setInner] = React.useState(defaultChecked);
  const on = checked ?? inner,
    s = String(size);
  const st = {
    "data-checked": da(on),
    "data-disabled": da(disabled)
  };
  const change = e => {
    if (checked == null) setInner(e.target.checked);
    onCheckedChange && onCheckedChange(e.target.checked);
  };
  return /*#__PURE__*/React.createElement("label", {
    className: cx(rc("seed-switch__root", {
      size: s
    }), className),
    "data-disabled": da(disabled),
    style: {
      position: "relative",
      ...style
    }
  }, /*#__PURE__*/React.createElement("div", _extends({
    className: rc("seed-switchmark__root", {
      tone,
      size: s
    })
  }, st), /*#__PURE__*/React.createElement("div", _extends({
    className: rc("seed-switchmark__thumb", {
      tone,
      size: s
    })
  }, st))), label != null && /*#__PURE__*/React.createElement("span", {
    className: rc("seed-switch__label", {
      size: s
    })
  }, label), /*#__PURE__*/React.createElement("input", {
    type: "checkbox",
    role: "switch",
    checked: on,
    disabled: disabled,
    onChange: change,
    style: {
      position: "absolute",
      opacity: 0,
      width: 1,
      height: 1,
      margin: 0
    }
  }));
}
Object.assign(__ds_scope, { Switch });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/forms/Switch.jsx", error: String((e && e.message) || e) }); }

// components/forms/TextField.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
const cx = (...a) => a.filter(Boolean).join(" ");
const rc = (b, v, pairs) => {
  const o = [b];
  for (const k in v || {}) if (v[k] != null && v[k] !== false) o.push(b + "--" + k + "_" + v[k]);
  for (const p of pairs || []) if (v[p[0]] != null && v[p[1]] != null) o.push(b + "--" + p[0] + "_" + v[p[0]] + "-" + p[1] + "_" + v[p[1]]);
  return o.join(" ");
};
const da = on => on ? "" : undefined;
function TextField({
  label,
  labelWeight = "medium",
  indicator,
  required,
  description,
  errorMessage,
  invalid,
  disabled,
  readOnly,
  variant = "outline",
  size = "large",
  placeholder,
  value,
  defaultValue,
  onValueChange,
  prefix,
  suffix,
  prefixIcon,
  suffixIcon,
  maxLength,
  multiline = false,
  rows = 3,
  className,
  style
}) {
  const [inner, setInner] = React.useState(defaultValue ?? "");
  const v = value ?? inner;
  const [focus, setFocus] = React.useState(false);
  const k = {
    variant,
    size
  };
  const vs = "--variant_" + variant + "-size_" + size;
  const st = {
    "data-invalid": da(invalid),
    "data-disabled": da(disabled),
    "data-readonly": da(readOnly),
    "data-focus": da(focus)
  };
  const Input = multiline ? "textarea" : "input";
  return /*#__PURE__*/React.createElement("div", {
    className: cx("seed-field__root", className),
    "data-invalid": da(invalid),
    style: {
      display: "flex",
      flexDirection: "column",
      ...style
    }
  }, (label || indicator) && /*#__PURE__*/React.createElement("div", {
    className: "seed-field__header"
  }, /*#__PURE__*/React.createElement("label", {
    className: rc("seed-field-label__root", {
      weight: labelWeight
    })
  }, label, required && /*#__PURE__*/React.createElement("span", {
    style: {
      color: "var(--seed-color-fg-brand)"
    }
  }, " *"), indicator && /*#__PURE__*/React.createElement("span", {
    className: "seed-field-label__indicatorText"
  }, indicator))), /*#__PURE__*/React.createElement("div", _extends({
    className: rc("seed-text-input__root", k, [["variant", "size"]])
  }, st, {
    style: multiline ? {
      height: "auto",
      alignItems: "flex-start"
    } : undefined
  }), prefixIcon && /*#__PURE__*/React.createElement(__ds_scope.PrefixIcon, {
    src: prefixIcon,
    className: "seed-text-input__prefixIcon seed-text-input__prefixIcon" + vs
  }), prefix && /*#__PURE__*/React.createElement("span", {
    className: "seed-text-input__prefixText seed-text-input__prefixText" + vs
  }, prefix), /*#__PURE__*/React.createElement(Input, _extends({
    className: rc("seed-text-input__value", k, [["variant", "size"]])
  }, st, {
    rows: multiline ? rows : undefined,
    placeholder: placeholder,
    value: v,
    maxLength: maxLength,
    disabled: disabled,
    readOnly: readOnly,
    onFocus: () => setFocus(true),
    onBlur: () => setFocus(false),
    onChange: e => {
      if (value == null) setInner(e.target.value);
      onValueChange && onValueChange(e.target.value);
    },
    style: multiline ? {
      resize: "none",
      paddingBlock: 13
    } : undefined
  })), suffix && /*#__PURE__*/React.createElement("span", {
    className: "seed-text-input__suffixText seed-text-input__suffixText" + vs
  }, suffix), suffixIcon && /*#__PURE__*/React.createElement(__ds_scope.SuffixIcon, {
    src: suffixIcon,
    className: "seed-text-input__suffixIcon seed-text-input__suffixIcon" + vs
  })), (description || invalid && errorMessage || maxLength) && /*#__PURE__*/React.createElement("div", {
    className: "seed-field__footer"
  }, invalid && errorMessage ? /*#__PURE__*/React.createElement("span", {
    className: "seed-field__errorMessage"
  }, errorMessage) : description ? /*#__PURE__*/React.createElement("span", {
    className: "seed-field__description"
  }, description) : /*#__PURE__*/React.createElement("span", null), maxLength && /*#__PURE__*/React.createElement("span", {
    className: "seed-field__characterCountArea"
  }, /*#__PURE__*/React.createElement("span", {
    className: "seed-field__characterCount",
    "data-empty": da(!v.length)
  }, v.length), /*#__PURE__*/React.createElement("span", {
    className: "seed-field__maxCharacterCount"
  }, "/", maxLength))));
}
Object.assign(__ds_scope, { TextField });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/forms/TextField.jsx", error: String((e && e.message) || e) }); }

// components/navigation/AppBar.jsx
try { (() => {
const cx = (...a) => a.filter(Boolean).join(" ");
const rc = (b, v, pairs) => {
  const o = [b];
  for (const k in v || {}) if (v[k] != null && v[k] !== false) o.push(b + "--" + k + "_" + v[k]);
  for (const p of pairs || []) if (v[p[0]] != null && v[p[1]] != null) o.push(b + "--" + p[0] + "_" + v[p[0]] + "-" + p[1] + "_" + v[p[1]]);
  return o.join(" ");
};
const da = on => on ? "" : undefined;
function AppBar({
  title,
  subtitle,
  theme = "cupertino",
  tone = "layer",
  left,
  right,
  back,
  onBack,
  divider = false,
  titleAlign,
  children,
  className,
  style
}) {
  const t = {
    theme,
    tone
  };
  const btn = (b, i) => /*#__PURE__*/React.createElement("button", {
    key: i,
    type: "button",
    "aria-label": b.label,
    onClick: b.onClick,
    className: rc("seed-app-bar__iconButton", t),
    style: {
      position: "relative",
      color: "inherit",
      cursor: "pointer"
    }
  }, b.glyph ? /*#__PURE__*/React.createElement(__ds_scope.Glyph, {
    name: b.glyph,
    className: rc("seed-app-bar__icon", t)
  }) : /*#__PURE__*/React.createElement(__ds_scope.Icon, {
    slot: "none",
    src: b.icon,
    className: rc("seed-app-bar__icon", t)
  }), b.badge && /*#__PURE__*/React.createElement("span", {
    className: "seed-notification-badge seed-notification-badge--size_small",
    style: {
      position: "absolute",
      top: 9,
      right: 9
    }
  }));
  const lefts = [...(back ? [{
    glyph: "chevronLeft",
    label: "뒤로",
    onClick: onBack
  }] : []), ...(left || [])];
  const th = titleAlign === "left" ? "android" : theme;
  return /*#__PURE__*/React.createElement("div", {
    className: cx(rc("seed-app-bar__root", t), className),
    style: {
      color: tone === "layer" ? "var(--seed-color-fg-neutral)" : "#fff",
      ...style
    }
  }, /*#__PURE__*/React.createElement("div", {
    className: rc("seed-app-bar__background", {
      tone
    }),
    style: {
      background: tone === "layer" ? "var(--seed-color-bg-layer-default)" : "transparent",
      boxShadow: divider ? "inset 0 -1px var(--seed-color-stroke-neutral-muted)" : undefined
    }
  }), /*#__PURE__*/React.createElement("div", {
    className: rc("seed-app-bar__left", t)
  }, lefts.map(btn)), /*#__PURE__*/React.createElement("div", {
    className: rc("seed-app-bar-main__root", {
      theme: th,
      tone
    })
  }, children || /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      flexDirection: "column",
      overflow: "hidden"
    }
  }, /*#__PURE__*/React.createElement("span", {
    className: rc("seed-app-bar-main__title", {
      layout: subtitle ? "withSubtitle" : "titleOnly",
      tone
    })
  }, title), subtitle && /*#__PURE__*/React.createElement("span", {
    className: rc("seed-app-bar-main__subtitle", {
      layout: "withSubtitle",
      tone
    })
  }, subtitle))), /*#__PURE__*/React.createElement("div", {
    className: rc("seed-app-bar__right", t)
  }, (right || []).map(btn)));
}
Object.assign(__ds_scope, { AppBar });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/navigation/AppBar.jsx", error: String((e && e.message) || e) }); }

// components/navigation/ChipTabs.jsx
try { (() => {
const cx = (...a) => a.filter(Boolean).join(" ");
const rc = (b, v, pairs) => {
  const o = [b];
  for (const k in v || {}) if (v[k] != null && v[k] !== false) o.push(b + "--" + k + "_" + v[k]);
  for (const p of pairs || []) if (v[p[0]] != null && v[p[1]] != null) o.push(b + "--" + p[0] + "_" + v[p[0]] + "-" + p[1] + "_" + v[p[1]]);
  return o.join(" ");
};
const da = on => on ? "" : undefined;
function ChipTabs({
  tabs = [],
  value,
  defaultValue,
  onValueChange,
  variant = "neutralSolid",
  size = "medium",
  children,
  className,
  style
}) {
  const [inner, setInner] = React.useState(defaultValue ?? (tabs[0] && tabs[0].value));
  const cur = value ?? inner;
  return /*#__PURE__*/React.createElement("div", {
    className: cx(rc("seed-chip-tabs__root", {
      contentLayout: "hug"
    }), className),
    style: style
  }, /*#__PURE__*/React.createElement("div", {
    role: "tablist",
    className: rc("seed-chip-tabs__list", {
      size
    })
  }, tabs.map(t => /*#__PURE__*/React.createElement("button", {
    key: t.value,
    type: "button",
    role: "tab",
    "aria-selected": cur === t.value,
    "data-selected": da(cur === t.value),
    className: rc("seed-chip-tabs__trigger", {
      size,
      variant
    }),
    onClick: () => {
      if (value == null) setInner(t.value);
      onValueChange && onValueChange(t.value);
    },
    style: {
      fontFamily: "inherit"
    }
  }, t.label))), typeof children === "function" ? children(cur) : children);
}
Object.assign(__ds_scope, { ChipTabs });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/navigation/ChipTabs.jsx", error: String((e && e.message) || e) }); }

// components/navigation/ListItem.jsx
try { (() => {
const cx = (...a) => a.filter(Boolean).join(" ");
const rc = (b, v, pairs) => {
  const o = [b];
  for (const k in v || {}) if (v[k] != null && v[k] !== false) o.push(b + "--" + k + "_" + v[k]);
  for (const p of pairs || []) if (v[p[0]] != null && v[p[1]] != null) o.push(b + "--" + p[0] + "_" + v[p[0]] + "-" + p[1] + "_" + v[p[1]]);
  return o.join(" ");
};
const da = on => on ? "" : undefined;
function ListItem({
  title,
  detail,
  prefix,
  suffix,
  onClick,
  highlighted,
  disabled,
  alignItems = "center",
  className,
  style
}) {
  const Content = onClick ? "button" : "div";
  return /*#__PURE__*/React.createElement("li", {
    className: cx("seed-list-item__root", className),
    "data-disabled": da(disabled),
    style: {
      "--seed-box-align-items": alignItems,
      alignItems,
      listStyle: "none",
      ...style
    }
  }, prefix && /*#__PURE__*/React.createElement("div", {
    className: "seed-list-item__prefix",
    style: {
      paddingRight: 12
    }
  }, prefix), /*#__PURE__*/React.createElement(Content, {
    type: onClick ? "button" : undefined,
    onClick: onClick,
    className: rc("seed-list-item__content", {
      highlighted: highlighted ? "true" : null
    }),
    style: {
      gap: 2,
      paddingRight: suffix ? 12 : 0
    }
  }, /*#__PURE__*/React.createElement("div", {
    className: "seed-list-item__title"
  }, title), detail && /*#__PURE__*/React.createElement("div", {
    className: "seed-list-item__detail"
  }, detail)), suffix && /*#__PURE__*/React.createElement("div", {
    className: "seed-list-item__suffix",
    style: {
      gap: 4
    }
  }, suffix));
}
function List({
  children,
  className,
  style
}) {
  return /*#__PURE__*/React.createElement("ul", {
    className: className,
    style: {
      display: "flex",
      flexDirection: "column",
      margin: 0,
      padding: 0,
      ...style
    }
  }, children);
}
function ListHeader({
  variant = "mediumWeak",
  children,
  className,
  style
}) {
  return /*#__PURE__*/React.createElement("div", {
    className: cx(rc("seed-list-header", {
      variant
    }), className),
    style: style
  }, children);
}
Object.assign(__ds_scope, { ListItem, List, ListHeader });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/navigation/ListItem.jsx", error: String((e && e.message) || e) }); }

// components/navigation/Tabs.jsx
try { (() => {
const cx = (...a) => a.filter(Boolean).join(" ");
const rc = (b, v, pairs) => {
  const o = [b];
  for (const k in v || {}) if (v[k] != null && v[k] !== false) o.push(b + "--" + k + "_" + v[k]);
  for (const p of pairs || []) if (v[p[0]] != null && v[p[1]] != null) o.push(b + "--" + p[0] + "_" + v[p[0]] + "-" + p[1] + "_" + v[p[1]]);
  return o.join(" ");
};
const da = on => on ? "" : undefined;
function Tabs({
  tabs = [],
  value,
  defaultValue,
  onValueChange,
  triggerLayout = "fill",
  size = "medium",
  sticky = false,
  children,
  className,
  style
}) {
  const [inner, setInner] = React.useState(defaultValue ?? (tabs[0] && tabs[0].value));
  const cur = value ?? inner;
  const listRef = React.useRef(null);
  const [ind, setInd] = React.useState({
    left: 0,
    width: 0
  });
  React.useLayoutEffect(() => {
    const el = listRef.current && listRef.current.querySelector("[data-selected]");
    if (el) setInd({
      left: el.offsetLeft,
      width: el.offsetWidth
    });
  }, [cur, tabs.length]);
  return /*#__PURE__*/React.createElement("div", {
    className: cx(rc("seed-tabs__root", {
      size,
      contentLayout: "hug",
      stickyList: sticky ? "true" : null
    }), className),
    style: style
  }, /*#__PURE__*/React.createElement("div", {
    ref: listRef,
    role: "tablist",
    className: rc("seed-tabs__list", {
      triggerLayout,
      size,
      stickyList: sticky ? "true" : null
    })
  }, tabs.map(t => /*#__PURE__*/React.createElement("button", {
    key: t.value,
    type: "button",
    role: "tab",
    "aria-selected": cur === t.value,
    "data-selected": da(cur === t.value),
    className: rc("seed-tabs__trigger", {
      triggerLayout,
      size
    }),
    onClick: () => {
      if (value == null) setInner(t.value);
      onValueChange && onValueChange(t.value);
    },
    style: {
      fontFamily: "inherit"
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      position: "relative"
    }
  }, t.label, t.notification && /*#__PURE__*/React.createElement("span", {
    className: "seed-notification-badge seed-notification-badge--size_small",
    style: {
      position: "absolute",
      top: 1,
      right: -8
    }
  })))), /*#__PURE__*/React.createElement("div", {
    className: rc("seed-tabs__indicator", {
      triggerLayout
    }),
    style: {
      "--indicator-left": ind.left + "px",
      "--indicator-width": ind.width + "px"
    }
  })), typeof children === "function" ? /*#__PURE__*/React.createElement("div", {
    className: "seed-tabs__content",
    "data-selected": ""
  }, children(cur)) : children);
}
Object.assign(__ds_scope, { Tabs });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/navigation/Tabs.jsx", error: String((e && e.message) || e) }); }

// components/overlays/AlertDialog.jsx
try { (() => {
const cx = (...a) => a.filter(Boolean).join(" ");
const rc = (b, v, pairs) => {
  const o = [b];
  for (const k in v || {}) if (v[k] != null && v[k] !== false) o.push(b + "--" + k + "_" + v[k]);
  for (const p of pairs || []) if (v[p[0]] != null && v[p[1]] != null) o.push(b + "--" + p[0] + "_" + v[p[0]] + "-" + p[1] + "_" + v[p[1]]);
  return o.join(" ");
};
const da = on => on ? "" : undefined;
const fixed = contained => contained ? {
  position: "absolute"
} : undefined;
function AlertDialog({
  open = true,
  title,
  description,
  actions = [],
  onClose,
  contained = false,
  layout,
  className,
  style
}) {
  if (!open) return null;
  const row = (layout || (actions.length === 2 ? "row" : "column")) === "row";
  return /*#__PURE__*/React.createElement("div", {
    className: "seed-alert-dialog__positioner",
    style: fixed(contained)
  }, /*#__PURE__*/React.createElement("div", {
    className: "seed-alert-dialog__backdrop",
    "data-state": "open",
    "data-open": "",
    style: fixed(contained),
    onClick: onClose
  }), /*#__PURE__*/React.createElement("div", {
    role: "alertdialog",
    className: cx("seed-alert-dialog__content", className),
    "data-state": "open",
    "data-open": "",
    style: style
  }, /*#__PURE__*/React.createElement("div", {
    className: "seed-alert-dialog__header"
  }, title && /*#__PURE__*/React.createElement("h2", {
    className: "seed-alert-dialog__title"
  }, title), description && /*#__PURE__*/React.createElement("p", {
    className: "seed-alert-dialog__description"
  }, description)), /*#__PURE__*/React.createElement("div", {
    className: "seed-alert-dialog__footer",
    style: {
      display: "flex",
      flexDirection: row ? "row" : "column",
      gap: 8
    }
  }, actions.map((a, i) => /*#__PURE__*/React.createElement(__ds_scope.ActionButton, {
    key: i,
    size: "large",
    variant: a.variant || (i === actions.length - 1 ? "neutralSolid" : "neutralWeak"),
    onClick: a.onClick,
    style: {
      flex: row ? 1 : undefined
    }
  }, a.label)))));
}
Object.assign(__ds_scope, { AlertDialog });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/overlays/AlertDialog.jsx", error: String((e && e.message) || e) }); }

// components/overlays/BottomSheet.jsx
try { (() => {
const cx = (...a) => a.filter(Boolean).join(" ");
const rc = (b, v, pairs) => {
  const o = [b];
  for (const k in v || {}) if (v[k] != null && v[k] !== false) o.push(b + "--" + k + "_" + v[k]);
  for (const p of pairs || []) if (v[p[0]] != null && v[p[1]] != null) o.push(b + "--" + p[0] + "_" + v[p[0]] + "-" + p[1] + "_" + v[p[1]]);
  return o.join(" ");
};
const da = on => on ? "" : undefined;
const fixed = contained => contained ? {
  position: "absolute"
} : undefined;
function BottomSheet({
  open = true,
  title,
  description,
  children,
  footer,
  onClose,
  showCloseButton = true,
  headerAlign = "left",
  contained = false,
  className,
  style
}) {
  if (!open) return null;
  return /*#__PURE__*/React.createElement("div", {
    className: "seed-bottom-sheet__positioner",
    style: fixed(contained)
  }, /*#__PURE__*/React.createElement("div", {
    className: "seed-bottom-sheet__backdrop",
    "data-state": "open",
    "data-open": "",
    style: fixed(contained),
    onClick: onClose
  }), /*#__PURE__*/React.createElement("div", {
    role: "dialog",
    className: cx("seed-bottom-sheet__content", className),
    "data-state": "open",
    "data-open": "",
    "data-show-close-button": da(showCloseButton),
    style: {
      animation: "drawer-slide-from-bottom var(--seed-duration-d6) var(--seed-timing-function-enter-expressive)",
      ...style
    }
  }, /*#__PURE__*/React.createElement("div", {
    className: "seed-bottom-sheet-handle__root"
  }), (title || description) && /*#__PURE__*/React.createElement("div", {
    className: rc("seed-bottom-sheet__header", {
      headerAlign
    })
  }, title && /*#__PURE__*/React.createElement("h2", {
    className: rc("seed-bottom-sheet__title", {
      headerAlign
    })
  }, title), description && /*#__PURE__*/React.createElement("p", {
    className: "seed-bottom-sheet__description"
  }, description)), /*#__PURE__*/React.createElement("div", {
    className: "seed-bottom-sheet__body"
  }, children), footer && /*#__PURE__*/React.createElement("div", {
    className: "seed-bottom-sheet__footer"
  }, footer), showCloseButton && /*#__PURE__*/React.createElement("button", {
    type: "button",
    "aria-label": "\uB2EB\uAE30",
    className: "seed-bottom-sheet__closeButton",
    onClick: onClose
  }, /*#__PURE__*/React.createElement("svg", {
    viewBox: "0 0 24 24",
    fill: "currentColor",
    width: "22",
    height: "22"
  }, /*#__PURE__*/React.createElement("path", {
    d: "M3.73 3.73c.3-.3.79-.3 1.09 0L12 10.91l7.18-7.18c.3-.3.79-.3 1.09 0 .3.3.3.79 0 1.09L13.09 12l7.18 7.18c.3.3.3.79 0 1.09-.3.3-.79.3-1.09 0L12 13.09l-7.18 7.18c-.3.3-.79.3-1.09 0-.3-.3-.3-.79 0-1.09L10.91 12 3.73 4.82c-.3-.3-.3-.79 0-1.09Z"
  })))));
}
Object.assign(__ds_scope, { BottomSheet });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/overlays/BottomSheet.jsx", error: String((e && e.message) || e) }); }

// components/overlays/MenuSheet.jsx
try { (() => {
const cx = (...a) => a.filter(Boolean).join(" ");
const rc = (b, v, pairs) => {
  const o = [b];
  for (const k in v || {}) if (v[k] != null && v[k] !== false) o.push(b + "--" + k + "_" + v[k]);
  for (const p of pairs || []) if (v[p[0]] != null && v[p[1]] != null) o.push(b + "--" + p[0] + "_" + v[p[0]] + "-" + p[1] + "_" + v[p[1]]);
  return o.join(" ");
};
const da = on => on ? "" : undefined;
const fixed = contained => contained ? {
  position: "absolute"
} : undefined;
function MenuSheet({
  open = true,
  title,
  description,
  groups = [],
  onClose,
  closeLabel = "닫기",
  labelAlign = "left",
  contained = false,
  className,
  style
}) {
  if (!open) return null;
  return /*#__PURE__*/React.createElement("div", {
    className: "seed-menu-sheet__positioner",
    style: fixed(contained)
  }, /*#__PURE__*/React.createElement("div", {
    className: "seed-menu-sheet__backdrop",
    "data-state": "open",
    "data-open": "",
    style: fixed(contained),
    onClick: onClose
  }), /*#__PURE__*/React.createElement("div", {
    role: "dialog",
    className: cx("seed-menu-sheet__content", className),
    "data-state": "open",
    "data-open": "",
    style: style
  }, (title || description) && /*#__PURE__*/React.createElement("div", {
    className: "seed-menu-sheet__header"
  }, title && /*#__PURE__*/React.createElement("h2", {
    className: "seed-menu-sheet__title"
  }, title), description && /*#__PURE__*/React.createElement("p", {
    className: "seed-menu-sheet__description"
  }, description)), /*#__PURE__*/React.createElement("div", {
    className: "seed-menu-sheet__list"
  }, groups.map((g, gi) => /*#__PURE__*/React.createElement("div", {
    key: gi,
    className: "seed-menu-sheet__group"
  }, g.map((it, i) => /*#__PURE__*/React.createElement("button", {
    key: i,
    type: "button",
    onClick: it.onClick,
    className: cx(rc("seed-menu-sheet-item__root", {
      tone: it.tone || "neutral"
    }), labelAlign === "center" ? "seed-menu-sheet-item__root--labelAlign_center" : "")
  }, /*#__PURE__*/React.createElement("div", {
    className: rc("seed-menu-sheet-item__content", {
      labelAlign
    })
  }, /*#__PURE__*/React.createElement("span", {
    className: rc("seed-menu-sheet-item__label", {
      tone: it.tone || "neutral"
    })
  }, it.label), it.description && /*#__PURE__*/React.createElement("span", {
    className: "seed-menu-sheet-item__description"
  }, it.description))))))), /*#__PURE__*/React.createElement("div", {
    className: "seed-menu-sheet__footer"
  }, /*#__PURE__*/React.createElement("button", {
    type: "button",
    className: "seed-menu-sheet__closeButton",
    onClick: onClose
  }, closeLabel))));
}
Object.assign(__ds_scope, { MenuSheet });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/overlays/MenuSheet.jsx", error: String((e && e.message) || e) }); }

// ui_kits/seed-demo-app/ArticleDetailScreen.jsx
try { (() => {
const {
  AppBar: DAppBar,
  Text: DText,
  Badge: DBadge,
  TagGroup: DTagGroup,
  Avatar: DAvatar,
  Callout,
  SegmentedControl,
  ResultSection: DResult,
  TextField,
  ActionButton,
  Skeleton,
  Icon: DIcon
} = window.SEEDDesignSystem_bc7187;
function ArticleDetailScreen({
  articleId,
  onBack
}) {
  const {
    ARTICLES,
    CATEGORIES,
    formatDate,
    icon
  } = window.DEMO;
  const article = ARTICLES.find(a => a.id === articleId);
  const cat = CATEGORIES.find(c => c.id === article?.categoryId)?.name;
  const [tone, setTone] = React.useState("transparent");
  const [loaded, setLoaded] = React.useState(false);
  const [draft, setDraft] = React.useState("");
  const [comments, setComments] = React.useState([]);
  const scrollRef = React.useRef(null);
  const onScroll = e => {
    const w = e.currentTarget.clientWidth;
    setTone(e.currentTarget.scrollTop > w - 56 ? "layer" : "transparent");
  };
  if (!article) return null;
  return /*#__PURE__*/React.createElement("div", {
    className: "screen",
    "data-screen-label": "02 Article detail"
  }, /*#__PURE__*/React.createElement(DAppBar, {
    tone: tone,
    back: true,
    onBack: onBack
  }), /*#__PURE__*/React.createElement("div", {
    className: "screen-content",
    ref: scrollRef,
    onScroll: onScroll,
    style: {
      paddingTop: 0
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      flexDirection: "column",
      gap: 16
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      aspectRatio: "1 / 1",
      position: "relative",
      isolation: "isolate"
    }
  }, /*#__PURE__*/React.createElement("img", {
    src: "../../assets/imagery/peng.jpeg",
    alt: "penguin",
    onLoad: () => setLoaded(true),
    style: {
      position: "absolute",
      zIndex: 1,
      width: "100%",
      height: "100%",
      objectFit: "cover"
    }
  }), !loaded && /*#__PURE__*/React.createElement(Skeleton, {
    width: "100%",
    height: "100%",
    radius: "0"
  })), /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      flexDirection: "column",
      gap: 24,
      paddingBottom: 16
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      flexDirection: "column",
      gap: 12,
      alignItems: "flex-start",
      padding: "0 16px"
    }
  }, article.isPopular && /*#__PURE__*/React.createElement(DBadge, {
    variant: "outline",
    tone: "brand",
    size: "large"
  }, "\uC778\uAE30"), /*#__PURE__*/React.createElement("article", {
    style: {
      display: "flex",
      flexDirection: "column",
      gap: 8
    }
  }, /*#__PURE__*/React.createElement(DText, {
    as: "h1",
    textStyle: "t7Bold",
    color: "var(--seed-color-fg-neutral)"
  }, article.title), /*#__PURE__*/React.createElement(DText, {
    as: "p",
    textStyle: "articleBody",
    color: "var(--seed-color-fg-neutral-muted)",
    style: {
      wordBreak: "keep-all"
    }
  }, article.content)), /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      width: "100%",
      alignItems: "center"
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      gap: 6,
      alignItems: "center",
      flexGrow: 1
    }
  }, /*#__PURE__*/React.createElement(DAvatar, {
    size: "20",
    fallback: /*#__PURE__*/React.createElement(DIcon, {
      src: icon("profile_fill"),
      size: 14,
      color: "var(--seed-color-palette-gray-500)"
    })
  }), /*#__PURE__*/React.createElement(DText, {
    textStyle: "t4Medium",
    color: "var(--seed-color-fg-neutral)"
  }, article.author)), /*#__PURE__*/React.createElement(DTagGroup, {
    size: "t3",
    tone: "neutralSubtle",
    tags: [cat, formatDate(article.createdAt)]
  }))), /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      flexDirection: "column",
      gap: 12,
      padding: "0 16px"
    }
  }, /*#__PURE__*/React.createElement(Callout, {
    tone: "neutral",
    description: "\uB530\uB73B\uD55C \uB313\uAE00\uC744 \uB0A8\uACA8\uC8FC\uC138\uC694.",
    prefixIcon: icon("info_fill")
  }), /*#__PURE__*/React.createElement(SegmentedControl, {
    options: [{
      value: "popular",
      label: "인기"
    }, {
      value: "latest",
      label: "최근"
    }],
    style: {
      width: "100%"
    }
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      padding: "12px 0"
    }
  }, comments.length === 0 ? /*#__PURE__*/React.createElement(DResult, {
    size: "medium",
    title: "\uB313\uAE00 \uC5C6\uC74C",
    description: "\uB313\uAE00\uC774 \uC5C6\uC2B5\uB2C8\uB2E4."
  }) : /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      flexDirection: "column",
      gap: 16
    }
  }, comments.map((c, i) => /*#__PURE__*/React.createElement("div", {
    key: i,
    style: {
      display: "flex",
      flexDirection: "column",
      gap: 6
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      gap: 6,
      alignItems: "center"
    }
  }, /*#__PURE__*/React.createElement(DAvatar, {
    size: "20",
    fallback: /*#__PURE__*/React.createElement(DIcon, {
      src: icon("profile_fill"),
      size: 14,
      color: "var(--seed-color-palette-gray-500)"
    })
  }), /*#__PURE__*/React.createElement(DText, {
    textStyle: "t4Medium"
  }, "\uB098")), /*#__PURE__*/React.createElement(DText, {
    as: "p",
    textStyle: "t4Regular",
    color: "var(--seed-color-fg-neutral-muted)",
    style: {
      margin: 0
    }
  }, c))))), /*#__PURE__*/React.createElement(TextField, {
    label: "\uB313\uAE00",
    multiline: true,
    maxLength: 200,
    placeholder: "\uC800\uB294\u2026",
    value: draft,
    onValueChange: setDraft
  }), /*#__PURE__*/React.createElement(ActionButton, {
    size: "large",
    variant: "neutralSolid",
    disabled: !draft.trim(),
    onClick: () => {
      setComments([...comments, draft.trim()]);
      setDraft("");
    }
  }, "\uAC8C\uC2DC"))))));
}
Object.assign(window, {
  ArticleDetailScreen
});
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/seed-demo-app/ArticleDetailScreen.jsx", error: String((e && e.message) || e) }); }

// ui_kits/seed-demo-app/FilterBottomSheet.jsx
try { (() => {
const {
  BottomSheet,
  Chip: FChip,
  ActionButton: FButton
} = window.SEEDDesignSystem_bc7187;
function FilterBottomSheet({
  open,
  current,
  onClose,
  onConfirm
}) {
  const {
    CATEGORIES
  } = window.DEMO;
  const [sel, setSel] = React.useState(current);
  React.useEffect(() => {
    if (open) setSel(current);
  }, [open]);
  return /*#__PURE__*/React.createElement(BottomSheet, {
    open: open,
    contained: true,
    title: "\uCE74\uD14C\uACE0\uB9AC",
    onClose: onClose,
    footer: /*#__PURE__*/React.createElement("div", {
      style: {
        display: "flex",
        paddingTop: 12
      }
    }, /*#__PURE__*/React.createElement(FButton, {
      flexGrow: true,
      size: "large",
      variant: "neutralSolid",
      onClick: () => {
        onConfirm(sel);
        onClose();
      }
    }, "\uC644\uB8CC"))
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      gap: 8,
      flexWrap: "wrap"
    }
  }, CATEGORIES.map(c => /*#__PURE__*/React.createElement(FChip, {
    key: c.id,
    variant: "outlineStrong",
    checked: sel.includes(c.id),
    onCheckedChange: on => setSel(on ? [...sel, c.id] : sel.filter(x => x !== c.id))
  }, c.name))));
}
Object.assign(window, {
  FilterBottomSheet
});
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/seed-demo-app/FilterBottomSheet.jsx", error: String((e && e.message) || e) }); }

// ui_kits/seed-demo-app/HomeScreen.jsx
try { (() => {
const {
  AppBar,
  Tabs,
  Chip,
  Avatar,
  Text,
  Badge,
  TagGroup,
  ResultSection,
  Icon
} = window.SEEDDesignSystem_bc7187;
const FILTERS = [{
  label: "카테고리",
  value: "category"
}, {
  label: "동네",
  value: "location"
}, {
  label: "작성자",
  value: "author"
}, {
  label: "작성 시간",
  value: "createdAt"
}];
function ArticleListItem({
  article,
  onOpen
}) {
  const {
    CATEGORIES,
    formatDate
  } = window.DEMO;
  const cat = CATEGORIES.find(c => c.id === article.categoryId)?.name;
  return /*#__PURE__*/React.createElement("button", {
    type: "button",
    onClick: onOpen,
    style: {
      all: "unset",
      cursor: "pointer",
      display: "flex",
      flexDirection: "column",
      gap: 10,
      padding: "4px 16px",
      textAlign: "start"
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      alignItems: "center",
      gap: 6
    }
  }, /*#__PURE__*/React.createElement(Avatar, {
    size: "20",
    fallback: /*#__PURE__*/React.createElement(Icon, {
      src: window.DEMO.icon("profile_fill"),
      size: 14,
      color: "var(--seed-color-palette-gray-500)"
    })
  }), /*#__PURE__*/React.createElement(Text, {
    textStyle: "t4Medium",
    color: "var(--seed-color-fg-neutral)"
  }, article.author)), /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      flexDirection: "column",
      gap: 8
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      flexDirection: "column",
      gap: 4
    }
  }, /*#__PURE__*/React.createElement(Text, {
    as: "h1",
    textStyle: "t5Bold",
    color: "var(--seed-color-fg-neutral)",
    maxLines: 1
  }, article.title), /*#__PURE__*/React.createElement(Text, {
    as: "p",
    textStyle: "t4Regular",
    color: "var(--seed-color-fg-neutral-muted)",
    maxLines: 2
  }, article.content)), /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      alignItems: "center",
      gap: 8
    }
  }, article.isPopular && /*#__PURE__*/React.createElement(Badge, {
    variant: "outline",
    tone: "brand"
  }, "\uC778\uAE30"), /*#__PURE__*/React.createElement(TagGroup, {
    size: "t4",
    tone: "neutralSubtle",
    tags: [cat, "서초2동", formatDate(article.createdAt)]
  }))));
}
function HomeScreen({
  selected,
  onOpenFilter,
  onUnavailableFilter,
  onOpenArticle
}) {
  const {
    ARTICLES,
    CATEGORIES
  } = window.DEMO;
  const [tab, setTab] = React.useState("recommendations");
  const list = (selected.length ? ARTICLES.filter(a => selected.includes(a.categoryId)) : ARTICLES).slice().sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt));
  const catLabel = selected.length ? selected.map(id => CATEGORIES.find(c => c.id === id)?.name).join(", ") : "카테고리";
  return /*#__PURE__*/React.createElement("div", {
    className: "screen",
    "data-screen-label": "01 Home"
  }, /*#__PURE__*/React.createElement(AppBar, {
    title: "Demo"
  }), /*#__PURE__*/React.createElement("div", {
    className: "screen-content"
  }, /*#__PURE__*/React.createElement(Tabs, {
    value: tab,
    onValueChange: setTab,
    triggerLayout: "fill",
    size: "medium",
    sticky: true,
    tabs: [{
      value: "recommendations",
      label: "추천"
    }, {
      value: "subscriptions",
      label: "구독"
    }]
  }), tab === "recommendations" ? /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      flexDirection: "column",
      gap: "var(--seed-dimension-spacing-y-component-default)",
      padding: "16px 0"
    }
  }, /*#__PURE__*/React.createElement("div", {
    className: "no-scrollbar",
    style: {
      display: "flex",
      gap: "var(--seed-dimension-spacing-x-between-chips)",
      padding: "0 16px",
      overflowX: "auto"
    }
  }, FILTERS.map(f => /*#__PURE__*/React.createElement(Chip, {
    key: f.value,
    checked: false,
    suffixIcon: window.DEMO.icon("expand_more_fill"),
    onCheckedChange: () => f.value === "category" ? onOpenFilter() : onUnavailableFilter()
  }, f.value === "category" ? catLabel : f.label))), /*#__PURE__*/React.createElement("ul", {
    style: {
      display: "flex",
      flexDirection: "column",
      gap: 16,
      margin: 0,
      padding: 0,
      listStyle: "none"
    }
  }, list.map(a => /*#__PURE__*/React.createElement("li", {
    key: a.id
  }, /*#__PURE__*/React.createElement(ArticleListItem, {
    article: a,
    onOpen: () => onOpenArticle(a.id)
  }))))) : /*#__PURE__*/React.createElement("div", {
    style: {
      padding: "48px 0"
    }
  }, /*#__PURE__*/React.createElement(ResultSection, {
    asset: /*#__PURE__*/React.createElement("div", {
      style: {
        paddingBottom: 16
      }
    }, /*#__PURE__*/React.createElement(Icon, {
      src: window.DEMO.icon("article_fill"),
      size: 40,
      color: "var(--seed-color-fg-neutral-subtle)"
    })),
    title: "\uAD6C\uB3C5\uD55C \uAE00\uC774 \uC5C6\uC2B5\uB2C8\uB2E4.",
    description: "\uCD94\uCC9C \uAE00\uC744 \uD655\uC778\uD574\uBCF4\uC138\uC694.",
    primaryActionProps: {
      children: "추천 글 보기",
      onClick: () => setTab("recommendations")
    }
  }))));
}
Object.assign(window, {
  HomeScreen
});
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/seed-demo-app/HomeScreen.jsx", error: String((e && e.message) || e) }); }

// ui_kits/seed-demo-app/data.js
try { (() => {
// Mirrors examples/stackflow-spa/src/demo-data.ts in daangn/seed-design
window.DEMO = {
  CATEGORIES: [{
    id: "travel",
    name: "여행"
  }, {
    id: "food",
    name: "음식"
  }, {
    id: "lifestyle",
    name: "라이프스타일"
  }],
  ARTICLES: [{
    id: 1,
    title: "산토리니의 일몰",
    content: "에게해의 푸른 바다와 하얀 건물들 사이로 지는 석양이 만드는 황홍빛 풍경. 산토리니에서 가장 로맨틱한 순간을 만날 수 있다.",
    author: "mollit",
    categoryId: "travel",
    createdAt: "2023-02-15T09:30:00Z"
  }, {
    id: 2,
    title: "교토의 대나무 숲",
    content: "아라시야마의 대나무 숲길을 걸으며 느끼는 고요함. 바람에 흔들리는 대나무 소리가 마음을 평온하게 만든다.",
    author: "sunt",
    categoryId: "travel",
    createdAt: "2023-05-22T14:15:00Z",
    isPopular: true
  }, {
    id: 3,
    title: "알프스 하이킹 가이드",
    content: "스위스 알프스의 초보자용 트레킹 코스. 그린델발트에서 시작하여 아이거 북벽을 감상하며 2시간 코스로 즐길 수 있다.",
    author: "ullamco",
    categoryId: "travel",
    createdAt: "2023-10-15T12:10:00Z"
  }, {
    id: 4,
    title: "홈메이드 파스타의 비밀",
    content: "신선한 면과 소스만 있다면 레스토랑 급 파스타를 만들 수 있다. 올리브오일과 마늘의 양이 맛을 결정한다.",
    author: "dolore",
    categoryId: "food",
    createdAt: "2023-03-30T16:20:00Z"
  }, {
    id: 5,
    title: "제철 딸기 고르는 법",
    content: "봄철 딸기는 꼭지가 선명한 초록색이어야 한다. 윤기 나는 빨간색과 은은한 향기가 좋은 딸기의 조건.",
    author: "aliqua",
    categoryId: "food",
    createdAt: "2023-06-18T10:05:00Z"
  }, {
    id: 6,
    title: "커피 브루잉 팁",
    content: "물 온도 92도, 분쇄도는 중간, 추출 시간 3분이 기본. 원두 양은 물 200ml당 15g이 황금비율이다.",
    author: "consectetur",
    categoryId: "food",
    createdAt: "2023-09-25T13:40:00Z"
  }, {
    id: 7,
    title: "미니멀 홈 데코",
    content: "불필요한 소품은 과감히 정리하고, 화이트 톤의 기본 가구만으로 깔끔한 공간을 연출할 수 있다.",
    author: "adipisicing",
    categoryId: "lifestyle",
    createdAt: "2023-04-12T15:55:00Z",
    isPopular: true
  }, {
    id: 8,
    title: "아침 루틴의 힘",
    content: "하루를 5분 일찍 시작하는 것부터. 따뜻한 물 한잔과 스트레칭으로 활기찬 아침을 맞이하자.",
    author: "elit",
    categoryId: "lifestyle",
    createdAt: "2023-07-28T08:25:00Z",
    isPopular: true
  }, {
    id: 9,
    title: "실내 공기 정화 식물",
    content: "스투키, 스파티필름, 산세베리아는 관리가 쉽고 공기정화 능력이 뛰어난 대표적인 실내식물이다.",
    author: "exercitation",
    categoryId: "lifestyle",
    createdAt: "2023-08-07T11:45:00Z"
  }, {
    id: 10,
    title: "독서 습관 만들기",
    content: "하루 10페이지부터 시작하자. 취침 전 20분 독서는 수면의 질도 높여주는 일석이조 습관이다.",
    author: "magna",
    categoryId: "lifestyle",
    createdAt: "2023-12-03T17:35:00Z",
    isPopular: true
  }],
  formatDate: s => new Date(s).toLocaleDateString("ko-KR", {
    month: "long",
    day: "numeric"
  }),
  icon: n => "../../assets/svg/icon_" + n + ".svg"
};
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/seed-demo-app/data.js", error: String((e && e.message) || e) }); }

__ds_ns.ActionButton = __ds_scope.ActionButton;

__ds_ns.ContextualFloatingButton = __ds_scope.ContextualFloatingButton;

__ds_ns.FloatingActionButton = __ds_scope.FloatingActionButton;

__ds_ns.ReactionButton = __ds_scope.ReactionButton;

__ds_ns.ToggleButton = __ds_scope.ToggleButton;

__ds_ns.Icon = __ds_scope.Icon;

__ds_ns.PrefixIcon = __ds_scope.PrefixIcon;

__ds_ns.SuffixIcon = __ds_scope.SuffixIcon;

__ds_ns.Glyph = __ds_scope.Glyph;

__ds_ns.Avatar = __ds_scope.Avatar;

__ds_ns.AvatarStack = __ds_scope.AvatarStack;

__ds_ns.Badge = __ds_scope.Badge;

__ds_ns.Divider = __ds_scope.Divider;

__ds_ns.MannerTempBadge = __ds_scope.MannerTempBadge;

__ds_ns.MannerTemp = __ds_scope.MannerTemp;

__ds_ns.NotificationBadge = __ds_scope.NotificationBadge;

__ds_ns.ProgressCircle = __ds_scope.ProgressCircle;

__ds_ns.ResultSection = __ds_scope.ResultSection;

__ds_ns.Skeleton = __ds_scope.Skeleton;

__ds_ns.TagGroup = __ds_scope.TagGroup;

__ds_ns.Text = __ds_scope.Text;

__ds_ns.Callout = __ds_scope.Callout;

__ds_ns.HelpBubble = __ds_scope.HelpBubble;

__ds_ns.PageBanner = __ds_scope.PageBanner;

__ds_ns.Snackbar = __ds_scope.Snackbar;

__ds_ns.Checkmark = __ds_scope.Checkmark;

__ds_ns.Checkbox = __ds_scope.Checkbox;

__ds_ns.Chip = __ds_scope.Chip;

__ds_ns.QuantityPicker = __ds_scope.QuantityPicker;

__ds_ns.Radiomark = __ds_scope.Radiomark;

__ds_ns.RadioGroup = __ds_scope.RadioGroup;

__ds_ns.SegmentedControl = __ds_scope.SegmentedControl;

__ds_ns.SelectBox = __ds_scope.SelectBox;

__ds_ns.Switch = __ds_scope.Switch;

__ds_ns.TextField = __ds_scope.TextField;

__ds_ns.AppBar = __ds_scope.AppBar;

__ds_ns.ChipTabs = __ds_scope.ChipTabs;

__ds_ns.ListItem = __ds_scope.ListItem;

__ds_ns.List = __ds_scope.List;

__ds_ns.ListHeader = __ds_scope.ListHeader;

__ds_ns.Tabs = __ds_scope.Tabs;

__ds_ns.AlertDialog = __ds_scope.AlertDialog;

__ds_ns.BottomSheet = __ds_scope.BottomSheet;

__ds_ns.MenuSheet = __ds_scope.MenuSheet;

})();
