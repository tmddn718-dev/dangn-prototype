# SEED Design System (당근 · Karrot)

SEED is the unified design language of **당근 (Karrot, formerly 당근마켓 / daangn)** — Korea's hyperlocal neighborhood app for second-hand trading (중고거래), local community (동네생활), jobs (알바), real estate, cars and local businesses. One token source feeds React, iOS, Android and Lynx, and syncs with Figma. Products are almost entirely **mobile-first, in-app webviews** built with Stackflow (native-like page stacks).

This project is a working copy of SEED for designing and prototyping: real tokens, the official recipe CSS, React components that compose those recipes, icons, and a click-through UI kit.

## Sources
- **GitHub — https://github.com/daangn/seed-design** (branch `dev`): tokens (`packages/css/base.css`), recipes (`packages/css/recipes/*.css`), React components (`packages/react/src/components`), registry snippets (`docs/registry/react/ui`), foundations docs (`docs/content/foundations/*.mdx`), demo app (`examples/stackflow-spa`).
- **GitHub — https://github.com/daangn/seed-icon** (branch `main`): SVG icon set (`assets/svg`).
- Docs site: https://seed-design.io
- Explore these repos further for anything not captured here (e.g. Lynx, Figma codegen, the newer `@karrotmarket/react-monochrome-icon` set, remaining components).

## Index
- `styles.css` — entry; `@import`s only. Link this one file.
- `tokens/` — `base.css` (dimension, radius, font size/line-height, weight, duration, easing, scale), `colors.css` (palette + semantic, light default, dark under `[data-seed-color-mode="dark-only"]`), `aliases.css` (short aliases + link colors), `utilities.css` (`.seed-icon` slots, scale-feedback, keyframes), `fonts.css` (Pretendard CDN).
- `recipes/` — 52 official SEED component stylesheets (BEM-ish `seed-<comp>__<slot>--<variant>_<value>` + `data-*` state).
- `components/` — React components (see list). Each has `.jsx`, `.d.ts`, `.prompt.md`; one card per folder.
- `guidelines/` — foundation specimen cards (Colors, Type, Spacing, Brand).
- `assets/brand/` — SEED logo, favicon, app icon, cover. `assets/svg/` — icons. `assets/imagery/peng.jpeg` — demo photo.
- `ui_kits/seed-demo-app/` — Stackflow demo app recreation.
- `templates/seed-mobile-screen/` — starter template (AppBar · Tabs · Chip · 글 목록 · FAB) for consuming projects.
- `SKILL.md`, `github.md`, `thumbnail.html`.

## Components
Namespace in cards/kits: `window.SEEDDesignSystem_bc7187`.
- **core**: Icon (+ PrefixIcon, SuffixIcon, Glyph)
- **actions**: ActionButton, ToggleButton, ReactionButton, FloatingActionButton, ContextualFloatingButton
- **display**: Badge, NotificationBadge, Avatar (+ AvatarStack), MannerTempBadge (+ MannerTemp), Skeleton, ProgressCircle, Text, Divider, TagGroup, ResultSection
- **feedback**: Callout, PageBanner, Snackbar, HelpBubble
- **forms**: Checkbox (+ Checkmark), RadioGroup (+ Radiomark), Switch, TextField, Chip, SegmentedControl, QuantityPicker, SelectBox
- **navigation**: AppBar, Tabs, ChipTabs, ListItem (+ List, ListHeader)
- **overlays**: AlertDialog, BottomSheet, MenuSheet

**Not yet built** (exist in SEED): Accordion, AttachmentInput/Display, DatePicker, WheelPicker, Slider, Select, Menu, Popover, HelpBubbleTooltip, SidePanel, SideNavigation, Pagination, ImageFrame, IdentityPlaceholder, PullToRefresh, ScrollFog, SwipeableMenuSheet, Responsive*, plus layout primitives (Box/Flex/Stack/Grid — use plain flex/grid with `--seed-dimension-*`).

**Intentional additions**: `Glyph` (inline check/minus/chevron/close paths so controls don't depend on asset paths); `ResultSection` is a registry snippet, not a core package export.

---

## CONTENT FUNDAMENTALS
Source: `docs/content/foundations/writing.mdx`. Korean first; warm, plain, neighborly.
- **Ending: 해요체 (~해요/~어요)**, not 합니다체. Use 합니다 only for automatic, safety-critical notices to add weight ("…보이는 메시지입니다.").
- **Minimize honorifics.** "최대 2개의 글을 등록할 수 있어요." not "등록하실 수 있어요". Exception: addressing a user by nickname — "보리엄마님, 거래 어떠셨나요?"
- **Familiar words** over Sino-Korean/technical: "대화할 수 없어요" not "대화가 불가능합니다". Errors explain what to do: "일시적으로 서비스를 사용할 수 없어요. 잠시 후 다시 시도해주세요."
- **Arabic numerals**: "당근 1개", "매일 5회까지".
- **No slang/abbreviations**: 끌어올리기, never 끌올 — even if users say it.
- **Purpose over feature name**: "채팅으로 거래하기" not "채팅하기"; "댓글을 좋아해요" not "좋아요를 눌렀어요".
- **Positive, active sentences**; describe the user's action, not data state: "거래 후기를 보냈어요" not "작성을 완료했어요".
- **Local community**: mention the neighborhood — "지금 역삼동 근처 주민들과…". Neighbors are 이웃; trading is 거래; Manner temperature is 매너온도 (36.5°C default).
- **Status names are written solid**: 예약중, 거래완료 (as labels); spaced in prose ("예약 중일 때는…").
- **Punctuation**: no period on titles, large text (≥20pt), buttons, menus, labels. Exclamation marks rarely.
- **Emoji**: not used in product UI copy. Person: the app speaks *to* the user ("~해보세요"), never "I".
- Button examples: 채팅하기, 완료, 게시, 적용하기, 닫기, 취소/삭제. Empty state: "구독한 글이 없습니다." + "추천 글을 확인해보세요."

## VISUAL FOUNDATIONS
- **Color**: Carrot orange `#FF6600` (`carrot-600`, `--seed-color-bg-brand-solid`) is the brand; reserve brand-solid for the *one* key action or brand moments — most buttons are `neutralSolid` (gray-900 `#2A3038`) or `neutralWeak` (gray-200). Neutrals are cool grays (`#F7F8F9`→`#1A1C20`). Semantic roles (informative blue `#217CF9`, positive green `#079171`, warning yellow, critical red `#FA342C`) each have solid/weak/contrast variants. Property → Role → Variant → State naming (`fg.neutral-muted`, `bg.brand-solid-pressed`).
- **Special palettes**: 10-level manner-temperature colors (gray → amber → orange → red); pastel `banner-*` tints; "magic" (AI) gradient orange→magenta `#F60 → #D25ACA` and soft glow — only for AI features.
- **Type**: system font (SF / Apple SD Gothic Neo on iOS, Roboto/Noto on Android) with Pretendard as cross-platform fallback. Scale t1–t14 = 11/12/13/14/16/18/20/22/24/26/28/32/40/48px; weights 400/500/700 only. Sizes scale with OS font settings (clamped 0.8×–1.5×; 1.35× on iOS). Titles are bold and compact; body t5 (16/22), article body 16/24.
- **Spacing**: 4px base with half steps (x0_5=2 … x16=64). Global gutter 16px, chip gap 8, component stack 12, nav→title 20, screen bottom 56.
- **Radius**: generous but not pill-everything — buttons 8 (medium) / 12 (large), dialogs 20, sheets 24 top corners, chips/segmented/badges/avatars full.
- **Elevation**: expressed three ways — surface color (layer-basement → default → floating; dark mode gets lighter as it rises), stroke (hairline `stroke.neutral-muted` 1px, e.g. tab list inset bottom), and shadow (s1 `0 1 4 #00000014`, s2 `0 2 10 #0000001A`, s3 `0 4 16 #0000001F`) used *sparingly* (FAB, contextual floating button). Cards are mostly borderless content on white; sections are separated by spacing, hairlines or basement-color bands, not drop-shadow cards.
- **Backgrounds**: flat white/near-white. No textures, patterns or decorative gradients. Imagery is user-generated product photos — natural, warm, unfiltered; shown full-bleed (1:1 hero on detail) or as rounded thumbnails.
- **Motion**: micro ≤200ms with `easing (.35,0,.35,1)`; macro >200ms with `enter (0,0,.15,1)` / `exit (.35,0,1,1)`; expressive variants for sheets (300ms `enter-expressive`). Stackflow cupertino page slide. Dialogs/snackbars fade+scale (0.8→1) via `seed-enter`. Respects reduced motion.
- **Press states**: background shifts to `*-pressed` token (one step darker; transparent elements get `black-alpha-100`), plus **scale feedback** — elements shrink by 2px of their height (`(h-2)/h`, ≈0.95). Hover only on fine pointers, same pressed color.
- **Focus**: 2px `blue-600` outline with 2px offset.
- **Disabled**: `bg.disabled` gray-200 + `fg.disabled` gray-500 (not opacity), except switches (38% opacity).
- **Transparency/blur**: overlay dims `black-alpha-700`; transparent app bar over hero images with white icons; no glassmorphism/backdrop blur.
- **Layout**: fixed 56px app bar (centered title on iOS, left on Android) above scrolling content; sticky tab lists; bottom sheets max 480px wide; floating buttons bottom-right; snackbars bottom-center, max 464px.

## ICONOGRAPHY
- SEED's current icon packages are `@karrotmarket/react-monochrome-icon` (monochrome: general, category and service icons) and `@karrotmarket/react-multicolor-icon`. Names look like `IconHouseLine`, `IconChevronLeftLine`, `IconCheckmarkFatFill`.
- Those packages weren't attached, so this project copies a subset of the **predecessor set `daangn/seed-icon`** (`assets/svg/icon_<name>_{regular|fill}.svg`, 24×24, `fill="currentColor"`, rounded terminals). Glyph shapes are close to the current set but naming differs — **flag: substitute set**.
- Style: 24px grid, ~1.5px-equivalent rounded line ("regular"/Line) for default state, solid "fill" for selected/active (e.g. tab bar home regular → fill). Icons inherit text color; size via `--seed-icon-size` (buttons 16–22px, list prefix 22, app bar 24).
- Usage here: `<Icon src="assets/svg/icon_home_regular.svg" />` (CSS-mask recolor) or inline SVG via `svg`.
- No icon font. No emoji or unicode-as-icon in UI (except `·` separators in TagGroup and `°C` in manner temperature).
- Logo: `assets/brand/seed-logo.svg` is the **SEED design-system** wordmark (not the 당근 app logo — none was provided). Where a 당근 product mark would go, set "당근" in bold type.

## Fonts
No font binaries ship in the repo; SEED relies on the OS font. `tokens/fonts.css` loads **Pretendard** from jsDelivr so non-Apple previews look right. Supply licensed font files if you need offline/exact rendering.
